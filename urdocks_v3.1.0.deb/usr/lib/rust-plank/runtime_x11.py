#!/usr/bin/env python3
"""
/usr/lib/rust-plank/runtime_x11.py
Complete Dual-Engine X11 Visual Dock Runtime for Urdocks v3.0.0 (formerly rust-plank).
Author: Haris Gitama (https://github.com/Harisgitama)

What's New in Urdocks v3.0.0 (Latest Release Build):
1. Rebranded to Urdocks v3.0.0 (`/usr/bin/urdocks` & `/usr/bin/rust-plank` compatibility):
   - Official Author attribution in Dock Preferences: Haris Gitama (`github.com/Harisgitama`).
2. Liquid Glass Theme Preset & Interactive Frosted Glass Slider:
   - Adds the new `Liquid Glass (Clear + Frosted)` preset rendering a crystal-clear refractive
     glass shelf with specular top highlights and an interactive `Frosted Glass` slider (0% Clear Glass
     to 100% Deep Frosted Glass) in `urdocks --preferences`.
3. Apple Continuous-Curve Superellipse (Squircle) Capsule Tooltips:
   - Upgraded hover tooltips to use G2 continuous-curvature cubic Bézier superellipse (squircle)
     capsule geometry so the transition from straight edges to curved capsule ends is seamless.
4. Click-to-Minimize Open Application with Native Linux Shrink-to-Dock Animation (`_NET_WM_ICON_GEOMETRY`):
   - Publishes exact dock icon screen coordinates via X11 `_NET_WM_ICON_GEOMETRY` on every open client
     window and invokes `XIconifyWindow` + `_NET_WM_STATE_HIDDEN` when clicking an already-open/focused
     application icon on the dock, triggering the native Linux Window Manager shrink effect directly
     into that dock icon.
5. Preserves All v2.1 Features:
   - Icon & Logo Preset Loader (`~/.local/share/plasma/desktoptheme/` & `/usr/share/icons/`).
   - Automatic live `_NET_CLIENT_LIST` running application detection & `[✓] Pin di Dock` checkbox.
   - Smooth 60 FPS autohide when pointer leaves dock area & active Linux system accent color sync.
"""

import ctypes
import glob
import gzip
import json
import math
import os
import pwd
import shutil
import subprocess
import sys
import tempfile
import time

CHANGELOG_TEXT = """========================================================================
urdocks (3.0.0) stable; urgency=high — CHANGELOG VERSI TERBARU (v3.0.0)
Author: Haris Gitama <https://github.com/Harisgitama>
========================================================================

  [ Major Release v3.0.0 — Urdocks Liquid Glass & Native Shrink Edition ]
  * [FEAT-3.0-01] Rebranding Resmi Menjadi "Urdocks" (v3.0.0):
    - Perubahan identitas aplikasi menjadi Urdocks (`/usr/bin/urdocks` dengan
      kompatibilitas penuh `/usr/bin/rust-plank`).
  * [FEAT-3.0-02] Preset Tema "Liquid Glass" + Slider "Frosted Glass":
    - Menambahkan preset tema baru `Liquid Glass (Clear Glass + Frosted)` yang
      membuat dock menjadi bening kristal (clear refractive glass) dilengkapi
      slider interaktif `Frosted Glass (0% - 100%)` pada Dock Preferences.
  * [FEAT-3.0-03] Tooltip Bentuk Capsule / Continuous Curve (Apple Superellipse / Squircle):
    - Memperbarui geometri tooltip menggunakan kurva Bézier kontinu superellipse
      (squircle) khas Apple sehingga transisi dari garis lurus ke ujung melengkung
      terlihat sangat halus tanpa patahan sudut.
  * [FEAT-3.0-04] Klik Aplikasi Terbuka untuk Minimize dengan Efek Shrink Linux ke Ikon Dock:
    - Menyinkronkan koordinat layar ikon dock ke atom X11 `_NET_WM_ICON_GEOMETRY`
      pada setiap jendela aplikasi yang sedang berjalan.
    - Saat aplikasi sedang terbuka/aktif lalu diklik kembali pada dock, aplikasi
      otomatis di-minimize (`XIconifyWindow` + `_NET_WM_STATE_HIDDEN`) dengan
      animasi shrink bawaan Linux langsung menuju ikon aplikasi tersebut di dock.
  * [FEAT-3.0-05] Profil Author di Dock Preferences:
    - Menambahkan kredit resmi Author: Haris Gitama beserta tautan langsung
      `github.com/Harisgitama` di dalam jendela Dock Preferences.

 -- Haris Gitama <https://github.com/Harisgitama>  Fri, 06 Nov 2026 22:25:00 +0700

========================================================================
urdocks / rust-plank (2.1.0) stable; urgency=medium
========================================================================

  [ Patch v2.1.0 — Fitur Baru & Peningkatan Visual ]
  * [FEAT-2.1-01] Pilih Icon Preset & Logo dari Tema Terinstal:
    - Memindai tema yang terinstal di `~/.local/share/plasma/desktoptheme/`
      (termasuk `/usr/share/plasma/desktoptheme/`) dan `/usr/share/icons`
      (termasuk `~/.local/share/icons` dan `~/.icons`).
    - Mendukung dekompresi otomatis ikon vektor KDE Plasma `.svgz` (gzip SVG),
      `.svg`, serta `.png` (termasuk logo launcher `start.svgz` / `start-here`).
  * [FEAT-2.1-02] Otomatis Masuk Dock (_NET_CLIENT_LIST) & Checkbox Pin di Dock:
    - Memantau aplikasi yang baru dibuka dan sedang dibuka secara real-time
      melalui atom X11 `_NET_CLIENT_LIST`, `WM_CLASS`, dan `_NET_WM_ICON`.
    - Menu Klik Kanan pada setiap aplikasi memiliki checkbox interaktif
      `[✓] Pin di Dock (Keep in Dock)` untuk menyematkan/melepas pin secara instan.
  * [FEAT-2.1-03] Fitur Autohide Halus Saat Mouse di Luar Area Dock:
    - Menyembunyikan dock secara mulus (60 FPS slide-out) saat mouse meninggalkan
      area dock dan memunculkannya kembali saat mouse mendekati tepi layar.
  * [FEAT-2.1-04] Animasi Smooth 60 FPS & Aksen Warna Mengikuti Sistem Linux Aktif:
    - Membaca warna aksen aktif secara langsung dari GTK3 `theme_selected_bg_color`,
      Linux Mint / Cinnamon / GNOME / MATE (`gsettings`), KDE Plasma (`kdeglobals`),
      dan `settings.ini`.

 -- Haris Gitama <https://github.com/Harisgitama>  Fri, 06 Nov 2026 12:30:00 +0700

========================================================================
rust-plank (2.0.0) stable; urgency=high
========================================================================

  * [FIX-2.0-01] Perbaikan x86_64 ELF64 SIB byte `0xCC` agar `$DISPLAY` dan
    `$XAUTHORITY` tidak hilang saat eksekusi.
  * [FIX-2.0-02] Implementasi Dual-Engine GTK3/GdkX11 + XRender ARGB8888 C-ABI.
  * [FIX-2.0-03] Perbaikan geometri rak kaca (glass shelf) agar tinggi rak tetap
    stabil saat ikon membesar (hover magnification).

 -- Haris Gitama <https://github.com/Harisgitama>  Fri, 06 Nov 2026 09:00:00 +0700
"""

# ============================================================================
# 1. CONFIGURATION, THEMES & LINUX SYSTEM ACCENT COLOR DETECTION
# ============================================================================

THEMES = [
    ("Liquid Glass (Clear + Frosted)", (0.82, 0.91, 1.0, 0.16), (1.0, 1.0, 1.0, 0.62)),
    ("macOS Sequoia Frost", (0.09, 0.11, 0.16, 0.86), (1.0, 1.0, 1.0, 0.30)),
    ("macOS Sonoma Dark", (0.05, 0.06, 0.10, 0.90), (1.0, 1.0, 1.0, 0.22)),
    ("macOS Light Glass", (0.93, 0.96, 0.99, 0.85), (1.0, 1.0, 1.0, 0.68)),
    ("Midnight Transparent", (0.03, 0.04, 0.07, 0.72), (0.38, 0.72, 1.0, 0.38)),
    ("Nordic Slate", (0.18, 0.20, 0.25, 0.90), (0.53, 0.75, 0.82, 0.36)),
]

MINT_AND_DISTRO_ACCENT_MAP = {
    "aqua": ((0.18, 0.70, 0.60), "Mint-Y Aqua (#2eb398)"),
    "teal": ((0.10, 0.72, 0.68), "Mint-Y Teal (#1ab8ad)"),
    "green": ((0.56, 0.75, 0.31), "Mint-Y Green (#8fa84f)"),
    "blue": ((0.21, 0.52, 0.89), "Desktop Blue (#3584e4)"),
    "sand": ((0.78, 0.65, 0.38), "Mint-Y Sand (#c8a662)"),
    "orange": ((0.91, 0.33, 0.13), "Ubuntu/Mint Orange (#e95420)"),
    "purple": ((0.66, 0.33, 0.97), "Desktop Purple (#a855f7)"),
    "pink": ((0.93, 0.28, 0.60), "Desktop Pink (#ec4899)"),
    "red": ((0.91, 0.26, 0.26), "Desktop Red (#e84343)"),
    "grey": ((0.55, 0.62, 0.70), "Mint-Y Grey (#8c9eb3)"),
    "yaru": ((0.91, 0.33, 0.13), "Ubuntu Yaru (#e95420)"),
    "breeze": ((0.24, 0.68, 0.91), "KDE Breeze Blue (#3daee9)"),
}

DEFAULT_PINNED_IDS = [
    "nemo.desktop",
    "firefox.desktop",
    "mate-terminal.desktop",
    "code.desktop",
    "xed.desktop",
    "gimp.desktop",
    "vlc.desktop",
]

DEFAULT_RUNTIME_CONFIG = {
    "position": "bottom",          # "bottom" | "top"
    "icon_size": 48,               # 32..84 px
    "icon_spacing": 10,            # 4..20 px
    "margin_px": 6,                # Extra gap from workarea edge
    "zoom_enabled": True,
    "zoom_max_scale": 1.58,
    "zoom_range_icons": 3.0,
    "theme_idx": 0,                # v3.0 Defaults to 0 = Liquid Glass (Clear + Frosted)
    "frosted_glass": 0.28,         # v3.0 Frosted Glass slider (0.00 = Clear Glass .. 1.00 = Frosted Glass)
    "icon_preset": "auto",         # "auto" | "icons:<name>" | "plasma:<name>" | "custom:<path>"
    "follow_system_accent": True,  # v2.1 Follow active Linux accent color
    "custom_accent_rgb": [0.18, 0.70, 0.60],
    "autohide": False,             # v2.1 Smooth autohide when mouse leaves dock
    "show_unpinned_running": True, # v2.1 Auto-insert running X11 apps into dock
    "click_to_minimize": True,     # v3.0 Click open app on dock -> minimize & shrink into dock icon
    "show_indicator_dots": True,
    "icon_reflection": True,
    "pinned_apps": list(DEFAULT_PINNED_IDS),
    "pinned_custom_meta": {},      # Stores metadata for newly pinned running apps
}

CONFIG_DIR = os.path.expanduser("~/.config/rust-plank")
CONFIG_JSON_PATH = os.path.join(CONFIG_DIR, "runtime_state.json")
SVGZ_CACHE_DIR = os.path.join(tempfile.gettempdir(), f"urdocks-svgz-{os.getuid()}")


def load_runtime_config():
    cfg = dict(DEFAULT_RUNTIME_CONFIG)
    try:
        if os.path.isfile(CONFIG_JSON_PATH):
            with open(CONFIG_JSON_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    cfg.update(data)
    except Exception:
        pass
    if not isinstance(cfg.get("pinned_apps"), list) or not cfg["pinned_apps"]:
        cfg["pinned_apps"] = list(DEFAULT_PINNED_IDS)
    if not isinstance(cfg.get("pinned_custom_meta"), dict):
        cfg["pinned_custom_meta"] = {}
    return cfg


def save_runtime_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(CONFIG_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass


def detect_linux_system_accent_color(gtk_widget=None):
    """
    Detects the active Linux system accent color from:
    0. Live GTK3 StyleContext `theme_selected_bg_color` if a GTK widget is active
    1. KDE Plasma `~/.config/kdeglobals` (`AccentColor=R,G,B`)
    2. Cinnamon / GNOME / MATE `gsettings` (`gtk-theme`, `icon-theme`, `accent-color`)
    3. `~/.config/gtk-3.0/settings.ini` (`gtk-theme-name` / `gtk-icon-theme-name`)
    Returns ((r, g, b), human_label).
    """
    if gtk_widget is not None:
        try:
            sc = gtk_widget.get_style_context()
            for color_name in ("theme_selected_bg_color", "accent_bg_color", " suggested_action_bg_color"):
                found, rgba = sc.lookup_color(color_name.strip())
                if found and (rgba.red + rgba.green + rgba.blue) > 0.08:
                    r, g, b = float(rgba.red), float(rgba.green), float(rgba.blue)
                    hex_str = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
                    return (r, g, b), f"GTK Active Accent ({hex_str})"
        except Exception:
            pass

    # 1. Check KDE Plasma ~/.config/kdeglobals
    kdeglobals = os.path.expanduser("~/.config/kdeglobals")
    if os.path.isfile(kdeglobals):
        try:
            with open(kdeglobals, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    s = line.strip()
                    if s.startswith("AccentColor=") or s.startswith("DecorationFocus="):
                        val = s.split("=", 1)[1].strip()
                        parts = [int(x.strip()) for x in val.split(",") if x.strip().isdigit()]
                        if len(parts) >= 3:
                            r, g, b = parts[0] / 255.0, parts[1] / 255.0, parts[2] / 255.0
                            hex_str = f"#{parts[0]:02x}{parts[1]:02x}{parts[2]:02x}"
                            return (r, g, b), f"KDE Plasma Accent ({hex_str})"
        except Exception:
            pass

    # 2. Check gsettings for Cinnamon, GNOME, MATE
    gsettings_queries = [
        ["gsettings", "get", "org.gnome.desktop.interface", "accent-color"],
        ["gsettings", "get", "org.cinnamon.desktop.interface", "gtk-theme"],
        ["gsettings", "get", "org.cinnamon.theme", "name"],
        ["gsettings", "get", "org.cinnamon.desktop.interface", "icon-theme"],
        ["gsettings", "get", "org.gnome.desktop.interface", "gtk-theme"],
        ["gsettings", "get", "org.mate.interface", "gtk-theme"],
    ]
    for cmd in gsettings_queries:
        try:
            out = subprocess.check_output(
                cmd, stderr=subprocess.DEVNULL, text=True, timeout=0.30
            ).strip().strip("'").lower()
            if out:
                for key, (rgb, label) in MINT_AND_DISTRO_ACCENT_MAP.items():
                    if key in out:
                        return rgb, f"{label} [{out}]"
        except Exception:
            pass

    # 3. Check ~/.config/gtk-3.0/settings.ini
    gtk_ini = os.path.expanduser("~/.config/gtk-3.0/settings.ini")
    if os.path.isfile(gtk_ini):
        try:
            with open(gtk_ini, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read().lower()
                for key, (rgb, label) in MINT_AND_DISTRO_ACCENT_MAP.items():
                    if key in content:
                        return rgb, label
        except Exception:
            pass

    return (0.18, 0.70, 0.60), "Linux Mint Aqua (#2eb398)"


# ============================================================================
# 2. AUTOMATIC X11 $DISPLAY & $XAUTHORITY DISCOVERY
# ============================================================================

def ensure_x11_environment():
    """
    Guarantees $DISPLAY, $XAUTHORITY, and $GDK_BACKEND=x11 are populated even if
    launched via sudo, a desktop launcher, or a stripped subshell.
    """
    os.environ.setdefault("GDK_BACKEND", "x11")

    display = os.environ.get("DISPLAY")
    if not display:
        sockets = sorted(glob.glob("/tmp/.X11-unix/X*"))
        for sock in sockets:
            num = os.path.basename(sock)[1:]
            if num.isdigit():
                display = f":{num}"
                os.environ["DISPLAY"] = display
                break

    if not os.environ.get("XAUTHORITY"):
        candidates = []
        sudo_user = os.environ.get("SUDO_USER")
        if sudo_user:
            try:
                pw = pwd.getpwnam(sudo_user)
                candidates.append(os.path.join(pw.pw_dir, ".Xauthority"))
                candidates.extend(glob.glob(f"/run/user/{pw.pw_uid}/gdm/Xauthority"))
                candidates.extend(glob.glob(f"/run/user/{pw.pw_uid}/xauth_*"))
            except KeyError:
                pass
        candidates.append(os.path.expanduser("~/.Xauthority"))
        candidates.extend(sorted(glob.glob("/tmp/xauth_*"), key=os.path.getmtime, reverse=True))
        candidates.extend(glob.glob(f"/run/user/{os.getuid()}/gdm/Xauthority"))
        candidates.extend(glob.glob(f"/run/user/{os.getuid()}/xauth_*"))
        for c in candidates:
            if os.path.isfile(c) and os.access(c, os.R_OK):
                os.environ["XAUTHORITY"] = c
                break

    return os.environ.get("DISPLAY")


# ============================================================================
# 3. ICON PRESET & KDE PLASMA DESKTOPTHEME + /USR/SHARE/ICONS ENGINE (v2.1)
# ============================================================================

PLASMA_ICON_ALIASES = {
    "start-here": ["start", "start-here-kde", "applications", "distributor-logo", "kde"],
    "view-app-grid-symbolic": ["start", "applications", "start-here-kde", "view-app-grid"],
    "system-file-manager": ["folder", "system-file-manager", "dolphin", "inode-directory", "system"],
    "firefox": ["internet-web-browser", "applications-internet", "network", "globe", "browser"],
    "utilities-terminal": ["utilities-terminal", "konsole", "terminal", "applications-system"],
    "com.visualstudio.code": ["applications-development", "code", "kate", "text-x-generic"],
    "accessories-text-editor": ["kate", "accessories-text-editor", "kwrite", "document-edit", "edit"],
    "gimp": ["applications-graphics", "gimp", "krita", "image-x-generic", "palette"],
    "vlc": ["applications-multimedia", "vlc", "media-playback-start", "audio", "video"],
    "preferences-system": ["configure", "preferences-system", "settings", "system"],
    "user-desktop": ["user-desktop", "desktop", "preferences-desktop-display", "computer"],
    "user-trash-full": ["user-trash-full", "user-trash", "trash-empty", "edit-delete"],
}


def discover_icon_and_plasma_presets():
    """
    Scans installed themes in:
      1. `~/.local/share/plasma/desktoptheme/` and `/usr/share/plasma/desktoptheme/`
      2. `/usr/share/icons/` and `~/.local/share/icons/` and `~/.icons/`
    Returns a list of tuples: `(preset_id, display_label, base_path, kind)`.
    """
    presets = [
        ("auto", "Auto (System Active Theme)", "", "auto"),
    ]
    seen_ids = {"auto"}

    # 1. Scan KDE Plasma desktoptheme directories
    plasma_roots = [
        os.path.expanduser("~/.local/share/plasma/desktoptheme"),
        "/usr/share/plasma/desktoptheme",
    ]
    for proot in plasma_roots:
        if not os.path.isdir(proot):
            continue
        try:
            entries = sorted(os.listdir(proot))
        except OSError:
            continue
        for entry in entries:
            if entry.startswith("."):
                continue
            full = os.path.join(proot, entry)
            if not os.path.isdir(full):
                continue
            pid = f"plasma:{entry}"
            if pid not in seen_ids:
                seen_ids.add(pid)
                short_root = (
                    "~/.local/share/plasma/desktoptheme"
                    if ".local" in proot
                    else "/usr/share/plasma/desktoptheme"
                )
                presets.append((pid, f"Plasma: {entry} ({short_root})", full, "plasma"))

    # 2. Scan /usr/share/icons and ~/.local/share/icons
    icon_roots = [
        os.path.expanduser("~/.local/share/icons"),
        os.path.expanduser("~/.icons"),
        "/usr/share/icons",
    ]
    priority_prefixes = (
        "Mint-Y",
        "Papirus",
        "Breeze",
        "WhiteSur",
        "Tela",
        "Yaru",
        "Adwaita",
        "elementary",
        "Numix",
        "Obsidian",
        "hicolor",
    )
    discovered_icons = []

    for iroot in icon_roots:
        if not os.path.isdir(iroot):
            continue
        try:
            entries = sorted(os.listdir(iroot))
        except OSError:
            continue
        for entry in entries:
            if entry.startswith(".") or entry in ("default", "locolor"):
                continue
            full = os.path.join(iroot, entry)
            if not os.path.isdir(full):
                continue
            has_icons = (
                os.path.isfile(os.path.join(full, "index.theme"))
                or os.path.isdir(os.path.join(full, "apps"))
                or os.path.isdir(os.path.join(full, "scalable"))
                or os.path.isdir(os.path.join(full, "48x48"))
                or os.path.isdir(os.path.join(full, "64x64"))
                or os.path.isdir(os.path.join(full, "128x128"))
            )
            if not has_icons:
                continue
            pid = f"icons:{entry}"
            if pid not in seen_ids:
                seen_ids.add(pid)
                short_root = "~/.local/share/icons" if ".local" in iroot else "/usr/share/icons"
                is_prio = any(entry.lower().startswith(p.lower()) for p in priority_prefixes)
                discovered_icons.append(
                    (
                        0 if is_prio else 1,
                        entry.lower(),
                        (pid, f"Icons: {entry} ({short_root})", full, "icons"),
                    )
                )

    discovered_icons.sort(key=lambda x: (x[0], x[1]))
    for _, _, item in discovered_icons[:60]:
        presets.append(item)

    return presets


def unpack_svgz_to_cache(svgz_path):
    """Decompresses a KDE Plasma `.svgz` icon to a temporary `.svg` file for GdkPixbuf/Cairo."""
    try:
        os.makedirs(SVGZ_CACHE_DIR, exist_ok=True)
        safe_name = svgz_path.replace("/", "_").replace(".", "_") + ".svg"
        out_path = os.path.join(SVGZ_CACHE_DIR, safe_name)
        if not os.path.isfile(out_path):
            with gzip.open(svgz_path, "rb") as f_in:
                with open(out_path, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        return out_path
    except Exception:
        return None


def find_icon_in_plasma_dir(pdir, candidate_stems):
    """Searches a Plasma desktoptheme directory (`icons/`, `widgets/`, or nested) for matching SVG/SVGZ/PNG."""
    search_subdirs = [
        os.path.join(pdir, "icons"),
        os.path.join(pdir, "apps"),
        os.path.join(pdir, "places"),
        os.path.join(pdir, "widgets"),
        pdir,
    ]
    for sdir in search_subdirs:
        if not os.path.isdir(sdir):
            continue
        for cstem in candidate_stems:
            if not cstem:
                continue
            for ext in (".svg", ".svgz", ".png"):
                cand = os.path.join(sdir, cstem + ext)
                if os.path.isfile(cand):
                    if ext == ".svgz":
                        unpacked = unpack_svgz_to_cache(cand)
                        if unpacked:
                            return unpacked
                    else:
                        return cand
    return None


def resolve_icon_path(icon_name, icon_preset="auto"):
    """
    Resolves an icon name or path across:
      1. Custom directory preset (`custom:/path/to/theme`)
      2. Selected KDE Plasma desktoptheme (`~/.local/share/plasma/desktoptheme/<theme>/icons/*.svg[z]`)
      3. Selected `/usr/share/icons/<theme>` or `~/.local/share/icons/<theme>`
      4. Fallback system icon themes (`Mint-Y*`, `Papirus*`, `Breeze*`, `Adwaita`, `hicolor`, `/usr/share/pixmaps`)
    """
    if not icon_name:
        return None
    if os.path.isabs(icon_name) and os.path.isfile(icon_name) and icon_preset == "auto":
        return icon_name

    stem = os.path.splitext(os.path.basename(icon_name))[0]
    candidate_stems = [
        icon_name,
        stem,
        stem.lower(),
        stem.split(".")[-1].lower(),
        stem.split("-")[0].lower(),
    ]
    for alias in PLASMA_ICON_ALIASES.get(stem, []):
        if alias not in candidate_stems:
            candidate_stems.append(alias)

    # 1. Check custom folder or Plasma desktoptheme preset
    plasma_dirs = []
    if icon_preset and icon_preset.startswith("custom:"):
        cpath = icon_preset.split(":", 1)[1]
        if os.path.isdir(cpath):
            plasma_dirs.append(cpath)
    elif icon_preset and icon_preset.startswith("plasma:"):
        tname = icon_preset.split(":", 1)[1]
        for root in (
            os.path.expanduser("~/.local/share/plasma/desktoptheme"),
            "/usr/share/plasma/desktoptheme",
        ):
            p = os.path.join(root, tname)
            if os.path.isdir(p):
                plasma_dirs.append(p)
    elif icon_preset == "auto":
        user_plasma = os.path.expanduser("~/.local/share/plasma/desktoptheme")
        if os.path.isdir(user_plasma):
            for d in sorted(glob.glob(os.path.join(user_plasma, "*"))):
                if os.path.isdir(d):
                    plasma_dirs.append(d)

    for pdir in plasma_dirs:
        found_plasma = find_icon_in_plasma_dir(pdir, candidate_stems)
        if found_plasma:
            return found_plasma

    # 2. Build ordered list of /usr/share/icons and ~/.local/share/icons directories
    theme_dirs = []
    if icon_preset and icon_preset.startswith("custom:"):
        cpath = icon_preset.split(":", 1)[1]
        if os.path.isdir(cpath):
            theme_dirs.append(cpath)
    elif icon_preset and icon_preset.startswith("icons:"):
        tname = icon_preset.split(":", 1)[1]
        for root in (
            os.path.expanduser("~/.local/share/icons"),
            os.path.expanduser("~/.icons"),
            "/usr/share/icons",
        ):
            cand_dir = os.path.join(root, tname)
            if os.path.isdir(cand_dir):
                theme_dirs.append(cand_dir)
                # Parse index.theme Inherits= chain so parent icon pack icons resolve cleanly
                idx_file = os.path.join(cand_dir, "index.theme")
                if os.path.isfile(idx_file):
                    try:
                        with open(idx_file, "r", encoding="utf-8", errors="ignore") as f:
                            for line in f:
                                if line.strip().startswith("Inherits="):
                                    parents = line.strip().split("=", 1)[1].split(",")
                                    for par in parents:
                                        par = par.strip()
                                        for r2 in (
                                            os.path.expanduser("~/.local/share/icons"),
                                            "/usr/share/icons",
                                        ):
                                            pdir = os.path.join(r2, par)
                                            if os.path.isdir(pdir) and pdir not in theme_dirs:
                                                theme_dirs.append(pdir)
                    except Exception:
                        pass

            if "-" in tname:
                base_variant = os.path.join(root, tname.split("-")[0] + "-" + tname.split("-")[1])
                if os.path.isdir(base_variant) and base_variant not in theme_dirs:
                    theme_dirs.append(base_variant)
                root_variant = os.path.join(root, tname.split("-")[0])
                if os.path.isdir(root_variant) and root_variant not in theme_dirs:
                    theme_dirs.append(root_variant)

    for pat in [
        os.path.expanduser("~/.local/share/icons/*"),
        os.path.expanduser("~/.icons/*"),
        "/usr/share/icons/Mint-Y*",
        "/usr/share/icons/Papirus*",
        "/usr/share/icons/breeze*",
        "/usr/share/icons/Yaru*",
        "/usr/share/icons/Adwaita*",
        "/usr/share/icons/gnome",
        "/usr/share/icons/hicolor",
    ]:
        for td in sorted(glob.glob(pat)):
            if os.path.isdir(td) and td not in theme_dirs:
                theme_dirs.append(td)

    subpaths = [
        "apps/64",
        "apps/48",
        "apps/scalable",
        "apps/128",
        "places/64",
        "places/48",
        "places/scalable",
        "scalable/apps",
        "scalable/places",
        "64x64/apps",
        "48x48/apps",
        "128x128/apps",
        "256x256/apps",
        "64x64/places",
        "48x48/places",
        "status/64",
        "status/48",
        "scalable/status",
    ]
    exts = [".svg", ".png"]
    for base in theme_dirs:
        for sub in subpaths:
            for cstem in candidate_stems:
                if not cstem:
                    continue
                for ext in exts:
                    cand = os.path.join(base, sub, cstem + ext)
                    if os.path.isfile(cand):
                        return cand

    for cstem in candidate_stems:
        for ext in exts:
            pix = f"/usr/share/pixmaps/{cstem}{ext}"
            if os.path.isfile(pix):
                return pix
    return None


def scan_desktop_entries():
    search_dirs = [
        os.path.expanduser("~/.local/share/applications"),
        "/usr/local/share/applications",
        "/usr/share/applications",
        "/var/lib/flatpak/exports/share/applications",
        "/var/lib/snapd/desktop/applications",
    ]
    entries = {}
    for d in reversed(search_dirs):
        if not os.path.isdir(d):
            continue
        for path in glob.glob(os.path.join(d, "*.desktop")):
            fname = os.path.basename(path)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    name, exec_cmd, icon, wm_class = None, None, None, None
                    no_display = False
                    in_main = False
                    for line in f:
                        s = line.strip()
                        if s.startswith("[") and s.endswith("]"):
                            in_main = s == "[Desktop Entry]"
                            continue
                        if in_main and "=" in s:
                            k, v = s.split("=", 1)
                            k = k.strip()
                            v = v.strip()
                            if k == "Name" and not name:
                                name = v
                            elif k == "Exec" and not exec_cmd:
                                exec_cmd = v
                            elif k == "Icon" and not icon:
                                icon = v
                            elif k == "StartupWMClass" and not wm_class:
                                wm_class = v
                            elif k == "NoDisplay" and v.lower() == "true":
                                no_display = True
                    if name and exec_cmd:
                        entries[fname] = {
                            "id": fname,
                            "name": name,
                            "exec": exec_cmd,
                            "icon": icon or "application-x-executable",
                            "wm_class": wm_class or "",
                            "no_display": no_display,
                        }
            except OSError:
                pass
    return entries


def get_trash_file_count():
    trash_files = os.path.expanduser("~/.local/share/Trash/files")
    if os.path.isdir(trash_files):
        try:
            return len([f for f in os.listdir(trash_files) if not f.startswith(".")])
        except OSError:
            pass
    return 0


def build_dock_items_catalog(cfg=None, entries=None):
    if cfg is None:
        cfg = load_runtime_config()
    if entries is None:
        entries = scan_desktop_entries()
    icon_preset = cfg.get("icon_preset", "auto")
    custom_meta = cfg.get("pinned_custom_meta", {})

    known_metadata = {
        "nemo.desktop": (["nemo.desktop", "caja.desktop", "org.gnome.Nautilus.desktop", "thunar.desktop"], "Files", "xdg-open ~", "system-file-manager", "files", (0.23, 0.51, 0.96)),
        "firefox.desktop": (["firefox.desktop", "firefox-esr.desktop", "chromium.desktop", "google-chrome.desktop"], "Firefox Web Browser", "x-www-browser", "firefox", "browser", (0.97, 0.45, 0.09)),
        "mate-terminal.desktop": (["mate-terminal.desktop", "org.gnome.Terminal.desktop", "xfce4-terminal.desktop", "konsole.desktop"], "Terminal", "x-terminal-emulator", "utilities-terminal", "terminal", (0.06, 0.72, 0.50)),
        "code.desktop": (["code.desktop", "codium.desktop"], "Visual Studio Code", "code", "com.visualstudio.code", "code", (0.05, 0.65, 0.91)),
        "xed.desktop": (["xed.desktop", "pluma.desktop", "org.gnome.TextEditor.desktop", "gedit.desktop"], "Text Editor", "xdg-open ~", "accessories-text-editor", "doc", (0.39, 0.40, 0.95)),
        "gimp.desktop": (["gimp.desktop", "pix.desktop", "org.gnome.eog.desktop"], "GIMP Image Studio", "gimp", "gimp", "palette", (0.66, 0.33, 0.97)),
        "vlc.desktop": (["vlc.desktop", "celluloid.desktop", "rhythmbox.desktop"], "VLC Media Player", "vlc", "vlc", "media", (0.92, 0.35, 0.05)),
    }

    items = [
        {
            "id": "launcher",
            "desktop_id": "applet://launcher",
            "name": "Applications",
            "exec": "xdg-open /usr/share/applications",
            "icon_name": "start-here",
            "icon_path": resolve_icon_path("start-here", icon_preset) or resolve_icon_path("view-app-grid-symbolic", icon_preset),
            "glyph": "launcher",
            "rgb": (0.22, 0.74, 0.97),
            "pinned": True,
            "is_applet": True,
            "running": False,
            "focused": False,
            "xids": [],
            "bounce_t": 0.0,
            "entry_scale": 1.0,
        }
    ]

    pinned_list = cfg.get("pinned_apps", DEFAULT_PINNED_IDS)
    seen_ids = set()

    for pid in pinned_list:
        if pid in known_metadata:
            candidates, fallback_name, fallback_exec, fallback_icon, glyph, rgb = known_metadata[pid]
        elif pid in custom_meta:
            cm = custom_meta[pid]
            candidates = [pid]
            fallback_name = cm.get("name", pid.replace(".desktop", "").capitalize())
            fallback_exec = cm.get("exec", pid.replace(".desktop", ""))
            fallback_icon = cm.get("icon_name", pid.replace(".desktop", "").lower())
            glyph = "doc"
            rgb = (0.28, 0.55, 0.92)
        else:
            candidates = [pid]
            fallback_name = pid.replace(".desktop", "").capitalize()
            fallback_exec = pid.replace(".desktop", "")
            fallback_icon = pid.replace(".desktop", "").lower()
            glyph = "doc"
            rgb = (0.30, 0.52, 0.88)

        matched = None
        for cid in candidates:
            if cid in entries:
                matched = entries[cid]
                break

        actual_id = matched["id"] if matched else candidates[0]
        if actual_id in seen_ids:
            continue
        seen_ids.add(actual_id)

        icon_name = matched["icon"] if matched else fallback_icon
        wm_c = matched.get("wm_class", "") if matched else custom_meta.get(pid, {}).get("wm_class", "")
        items.append(
            {
                "id": actual_id,
                "desktop_id": pid,
                "name": matched["name"] if matched else fallback_name,
                "exec": matched["exec"] if matched else fallback_exec,
                "icon_name": icon_name,
                "icon_path": resolve_icon_path(icon_name, icon_preset) or resolve_icon_path(fallback_icon, icon_preset),
                "wm_class": wm_c,
                "glyph": glyph,
                "rgb": rgb,
                "pinned": True,
                "is_applet": False,
                "running": False,
                "focused": False,
                "xids": [],
                "bounce_t": 0.0,
                "entry_scale": 1.0,
            }
        )

    items.append(
        {
            "id": "preferences",
            "desktop_id": "applet://preferences",
            "name": "Dock Preferences",
            "exec": "__open_preferences__",
            "icon_name": "preferences-system",
            "icon_path": resolve_icon_path("preferences-system", icon_preset) or resolve_icon_path("preferences-desktop", icon_preset),
            "glyph": "prefs",
            "rgb": (0.39, 0.45, 0.55),
            "pinned": True,
            "is_applet": True,
            "running": False,
            "focused": False,
            "xids": [],
            "bounce_t": 0.0,
            "entry_scale": 1.0,
        }
    )
    items.append(
        {
            "id": "show-desktop",
            "desktop_id": "applet://show-desktop",
            "name": "Show Desktop",
            "exec": "__toggle_desktop__",
            "icon_name": "user-desktop",
            "icon_path": resolve_icon_path("user-desktop", icon_preset),
            "glyph": "desktop",
            "rgb": (0.08, 0.72, 0.65),
            "pinned": True,
            "is_applet": True,
            "running": False,
            "focused": False,
            "xids": [],
            "bounce_t": 0.0,
            "entry_scale": 1.0,
        }
    )
    items.append(
        {
            "id": "trash",
            "desktop_id": "applet://trash",
            "name": "Trash",
            "exec": "xdg-open trash:///",
            "icon_name": "user-trash-full",
            "icon_path": resolve_icon_path("user-trash-full", icon_preset) or resolve_icon_path("user-trash", icon_preset),
            "glyph": "trash",
            "rgb": (0.45, 0.50, 0.60),
            "pinned": True,
            "is_applet": True,
            "running": False,
            "focused": False,
            "xids": [],
            "bounce_t": 0.0,
            "entry_scale": 1.0,
        }
    )
    return items


def launch_command(cmd_str):
    clean = cmd_str.split("%")[0].strip()
    if not clean:
        return
    try:
        subprocess.Popen(
            clean,
            shell=True,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


# ============================================================================
# 4. LIVE X11 `_NET_CLIENT_LIST` RUNNING WINDOW MATCHER & ACTIVATOR (v2.1)
# ============================================================================

XA_ATOM = 4
XA_CARDINAL = 6
XA_STRING = 31
XA_WINDOW = 33
AnyPropertyType = 0


def get_x11_window_string_prop(libX11, dpy, win, atom):
    if not atom:
        return ""
    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
    res = libX11.XGetWindowProperty(
        dpy,
        win,
        atom,
        0,
        256,
        0,
        AnyPropertyType,
        ctypes.byref(actual_type),
        ctypes.byref(actual_format),
        ctypes.byref(nitems),
        ctypes.byref(bytes_after),
        ctypes.byref(prop_ptr),
    )
    val = ""
    if res == 0 and prop_ptr and nitems.value > 0:
        raw = ctypes.string_at(prop_ptr, nitems.value)
        parts = [p.decode("utf-8", errors="ignore") for p in raw.split(b"\x00") if p]
        val = " | ".join(parts) if parts else ""
    if prop_ptr:
        libX11.XFree(prop_ptr)
    return val


def get_x11_window_atoms(libX11, dpy, win, prop_atom):
    if not prop_atom:
        return []
    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
    res = libX11.XGetWindowProperty(
        dpy,
        win,
        prop_atom,
        0,
        64,
        0,
        XA_ATOM,
        ctypes.byref(actual_type),
        ctypes.byref(actual_format),
        ctypes.byref(nitems),
        ctypes.byref(bytes_after),
        ctypes.byref(prop_ptr),
    )
    atoms = []
    if res == 0 and prop_ptr and nitems.value > 0:
        atoms = [prop_ptr[i] for i in range(nitems.value)]
    if prop_ptr:
        libX11.XFree(prop_ptr)
    return atoms


def extract_x11_net_wm_icon_pixbuf(libX11, dpy, xid, GdkPixbuf):
    """
    Extracts the highest-resolution 32-bit ARGB icon from X11 `_NET_WM_ICON`
    on `xid` and converts it into a `GdkPixbuf.Pixbuf` for unpinned / AppImage windows.
    """
    if not libX11 or not dpy or not xid or GdkPixbuf is None:
        return None
    atom_icon = libX11.XInternAtom(dpy, b"_NET_WM_ICON", 1)
    if not atom_icon:
        return None
    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
    res = libX11.XGetWindowProperty(
        dpy,
        xid,
        atom_icon,
        0,
        65536,
        0,
        XA_CARDINAL,
        ctypes.byref(actual_type),
        ctypes.byref(actual_format),
        ctypes.byref(nitems),
        ctypes.byref(bytes_after),
        ctypes.byref(prop_ptr),
    )
    pb = None
    try:
        if res == 0 and prop_ptr and nitems.value > 2:
            total = nitems.value
            idx = 0
            best_w, best_h, best_off = 0, 0, -1
            while idx + 2 <= total:
                w = int(prop_ptr[idx])
                h = int(prop_ptr[idx + 1])
                if w <= 0 or h <= 0 or w > 512 or h > 512 or (idx + 2 + w * h) > total:
                    break
                if w * h > best_w * best_h:
                    best_w, best_h, best_off = w, h, idx + 2
                idx += 2 + w * h
            if best_off >= 0 and best_w > 0 and best_h > 0:
                rgba_bytes = bytearray(best_w * best_h * 4)
                for p in range(best_w * best_h):
                    argb = int(prop_ptr[best_off + p]) & 0xFFFFFFFF
                    a = (argb >> 24) & 0xFF
                    r = (argb >> 16) & 0xFF
                    g = (argb >> 8) & 0xFF
                    b = argb & 0xFF
                    base = p * 4
                    rgba_bytes[base] = r
                    rgba_bytes[base + 1] = g
                    rgba_bytes[base + 2] = b
                    rgba_bytes[base + 3] = a
                from gi.repository import GLib
                gbytes = GLib.Bytes.new(bytes(rgba_bytes))
                pb = GdkPixbuf.Pixbuf.new_from_bytes(
                    gbytes, GdkPixbuf.Colorspace.RGB, True, 8, best_w, best_h, best_w * 4
                )
    except Exception:
        pb = None
    finally:
        if prop_ptr:
            libX11.XFree(prop_ptr)
    return pb


def query_live_x11_running_windows(libX11, dpy, root):
    """
    Reads `_NET_CLIENT_LIST` (or `_NET_CLIENT_LIST_STACKING`) and `_NET_ACTIVE_WINDOW`
    from the X11 root window.
    Returns `(active_xid, list_of_window_dicts)` where each dict has:
      `{"xid": int, "wm_class": str, "title": str}`.
    """
    atom_client_list = libX11.XInternAtom(dpy, b"_NET_CLIENT_LIST", 1)
    if not atom_client_list:
        atom_client_list = libX11.XInternAtom(dpy, b"_NET_CLIENT_LIST_STACKING", 1)
    atom_active_win = libX11.XInternAtom(dpy, b"_NET_ACTIVE_WINDOW", 1)
    atom_wm_class = libX11.XInternAtom(dpy, b"WM_CLASS", 1)
    atom_net_wm_name = libX11.XInternAtom(dpy, b"_NET_WM_NAME", 1)
    atom_wm_name = libX11.XInternAtom(dpy, b"WM_NAME", 1)
    atom_wtype = libX11.XInternAtom(dpy, b"_NET_WM_WINDOW_TYPE", 1)
    atom_wtype_dock = libX11.XInternAtom(dpy, b"_NET_WM_WINDOW_TYPE_DOCK", 1)
    atom_wtype_desktop = libX11.XInternAtom(dpy, b"_NET_WM_WINDOW_TYPE_DESKTOP", 1)
    atom_wstate = libX11.XInternAtom(dpy, b"_NET_WM_STATE", 1)
    atom_skip_taskbar = libX11.XInternAtom(dpy, b"_NET_WM_STATE_SKIP_TASKBAR", 1)
    atom_hidden = libX11.XInternAtom(dpy, b"_NET_WM_STATE_HIDDEN", 1)

    active_xid = 0
    if atom_active_win:
        actual_type = ctypes.c_ulong()
        actual_format = ctypes.c_int()
        nitems = ctypes.c_ulong()
        bytes_after = ctypes.c_ulong()
        prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
        if (
            libX11.XGetWindowProperty(
                dpy,
                root,
                atom_active_win,
                0,
                2,
                0,
                XA_WINDOW,
                ctypes.byref(actual_type),
                ctypes.byref(actual_format),
                ctypes.byref(nitems),
                ctypes.byref(bytes_after),
                ctypes.byref(prop_ptr),
            )
            == 0
            and prop_ptr
            and nitems.value >= 1
        ):
            active_xid = int(prop_ptr[0])
        if prop_ptr:
            libX11.XFree(prop_ptr)

    if not atom_client_list:
        return active_xid, []

    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
    res = libX11.XGetWindowProperty(
        dpy,
        root,
        atom_client_list,
        0,
        512,
        0,
        XA_WINDOW,
        ctypes.byref(actual_type),
        ctypes.byref(actual_format),
        ctypes.byref(nitems),
        ctypes.byref(bytes_after),
        ctypes.byref(prop_ptr),
    )
    xids = []
    if res == 0 and prop_ptr and nitems.value > 0:
        xids = [int(prop_ptr[i]) for i in range(nitems.value)]
    if prop_ptr:
        libX11.XFree(prop_ptr)

    windows = []
    for xid in xids:
        wtypes = get_x11_window_atoms(libX11, dpy, xid, atom_wtype)
        if atom_wtype_dock in wtypes or atom_wtype_desktop in wtypes:
            continue
        wstates = get_x11_window_atoms(libX11, dpy, xid, atom_wstate)
        if atom_skip_taskbar in wstates:
            continue

        wm_class_raw = get_x11_window_string_prop(libX11, dpy, xid, atom_wm_class)
        if not wm_class_raw or "rust-plank" in wm_class_raw.lower() or "urdocks" in wm_class_raw.lower():
            continue

        title = (
            get_x11_window_string_prop(libX11, dpy, xid, atom_net_wm_name)
            or get_x11_window_string_prop(libX11, dpy, xid, atom_wm_name)
            or wm_class_raw
        )
        windows.append(
            {
                "xid": xid,
                "wm_class": wm_class_raw,
                "title": title,
                "is_hidden": bool(atom_hidden and (atom_hidden in wstates)),
            }
        )
    return active_xid, windows


def match_window_to_desktop_entry(wm_class_raw, entries):
    parts = [p.strip().lower() for p in wm_class_raw.split("|") if p.strip()]
    if not parts:
        return None
    for _, ent in entries.items():
        if ent.get("no_display"):
            continue
        ent_id_stem = ent["id"].replace(".desktop", "").lower()
        ent_wmc = ent.get("wm_class", "").lower()
        ent_exec = os.path.basename(ent["exec"].split()[0]).lower() if ent["exec"] else ""
        for p in parts:
            if (
                (ent_wmc and p == ent_wmc)
                or p == ent_id_stem
                or ent_id_stem.endswith("." + p)
                or (ent_exec and p == ent_exec)
            ):
                return ent
    return None


def set_x11_window_icon_geometry(libX11, dpy, xid, root_x, root_y, width, height):
    """
    Sets EWMH `_NET_WM_ICON_GEOMETRY` (4 x 32-bit CARDINAL: [x, y, width, height])
    on `xid` so the Linux Window Manager (Muffin/Mutter/KWin/Xfwm4/Marco) shrinks
    the window directly toward this dock icon when minimized!
    """
    if not libX11 or not dpy or not xid:
        return
    atom_geom = libX11.XInternAtom(dpy, b"_NET_WM_ICON_GEOMETRY", 0)
    if not atom_geom:
        return
    GeomArray = ctypes.c_ulong * 4
    geom = GeomArray(
        max(0, int(root_x)),
        max(0, int(root_y)),
        max(1, int(width)),
        max(1, int(height)),
    )
    libX11.XChangeProperty(
        dpy,
        xid,
        atom_geom,
        XA_CARDINAL,
        32,
        PropModeReplace,
        ctypes.byref(geom),
        4,
    )


def minimize_x11_window_to_dock_icon(libX11, dpy, root, scr_num, xid, root_x, root_y, width, height):
    """
    Updates `_NET_WM_ICON_GEOMETRY` to the dock icon's exact screen coordinates
    and triggers native Linux window manager minimize (`XIconifyWindow` + `_NET_WM_STATE_HIDDEN`),
    causing the window to shrink smoothly into its dock icon.
    """
    set_x11_window_icon_geometry(libX11, dpy, xid, root_x, root_y, width, height)
    atom_wm_state = libX11.XInternAtom(dpy, b"_NET_WM_STATE", 0)
    atom_hidden = libX11.XInternAtom(dpy, b"_NET_WM_STATE_HIDDEN", 0)
    if atom_wm_state and atom_hidden:
        ev = XEvent()
        ev.xclient.type = ClientMessage
        ev.xclient.window = xid
        ev.xclient.message_type = atom_wm_state
        ev.xclient.format = 32
        ev.xclient.data[0] = 1  # _NET_WM_STATE_ADD
        ev.xclient.data[1] = atom_hidden
        ev.xclient.data[2] = 0
        ev.xclient.data[3] = 2  # Source indication: pager/dock
        ev.xclient.data[4] = 0
        libX11.XSendEvent(
            dpy,
            root,
            0,
            SubstructureRedirectMask | SubstructureNotifyMask,
            ctypes.byref(ev),
        )
    if hasattr(libX11, "XIconifyWindow"):
        libX11.XIconifyWindow(dpy, xid, scr_num)
    libX11.XFlush(dpy)


def activate_x11_window(libX11, dpy, root, xid, root_x=None, root_y=None, width=None, height=None):
    if root_x is not None and root_y is not None and width is not None and height is not None:
        set_x11_window_icon_geometry(libX11, dpy, xid, root_x, root_y, width, height)
    atom_wm_state = libX11.XInternAtom(dpy, b"_NET_WM_STATE", 0)
    atom_hidden = libX11.XInternAtom(dpy, b"_NET_WM_STATE_HIDDEN", 0)
    if atom_wm_state and atom_hidden:
        ev_unhide = XEvent()
        ev_unhide.xclient.type = ClientMessage
        ev_unhide.xclient.window = xid
        ev_unhide.xclient.message_type = atom_wm_state
        ev_unhide.xclient.format = 32
        ev_unhide.xclient.data[0] = 0  # _NET_WM_STATE_REMOVE
        ev_unhide.xclient.data[1] = atom_hidden
        ev_unhide.xclient.data[2] = 0
        ev_unhide.xclient.data[3] = 2
        ev_unhide.xclient.data[4] = 0
        libX11.XSendEvent(
            dpy,
            root,
            0,
            SubstructureRedirectMask | SubstructureNotifyMask,
            ctypes.byref(ev_unhide),
        )

    libX11.XMapRaised(dpy, xid)
    atom_active = libX11.XInternAtom(dpy, b"_NET_ACTIVE_WINDOW", 0)
    ev = XEvent()
    ev.xclient.type = ClientMessage
    ev.xclient.window = xid
    ev.xclient.message_type = atom_active
    ev.xclient.format = 32
    ev.xclient.data[0] = 2  # Source indication: pager/dock
    ev.xclient.data[1] = 0
    ev.xclient.data[2] = 0
    ev.xclient.data[3] = 0
    ev.xclient.data[4] = 0
    libX11.XSendEvent(
        dpy,
        root,
        0,
        SubstructureRedirectMask | SubstructureNotifyMask,
        ctypes.byref(ev),
    )
    libX11.XRaiseWindow(dpy, xid)
    libX11.XFlush(dpy)


# ============================================================================
# 5. PRIMARY ENGINE: GTK3 + GDKX11 + CAIRO (Urdocks v3.0.0)
# ============================================================================

def try_run_gtk_visual_dock(open_prefs_on_start=False):
    """
    Runs the native GTK3 + GdkX11 + Cairo visual dock window for Urdocks v3.0.0:
    - Liquid Glass theme preset (clear refractive glass + Frosted Glass slider 0%..100%)
    - Apple continuous-curve superellipse (squircle) capsule tooltips
    - Click open/focused app on dock to minimize with native Linux shrink-to-dock-icon animation (_NET_WM_ICON_GEOMETRY)
    - Author attribution: Haris Gitama (github.com/Harisgitama) in Dock Preferences
    - Preserves all v2.1 features (Icon Presets, _NET_CLIENT_LIST auto-dock, Pin checkbox, Autohide, System Accent)
    """
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        gi.require_version("Gdk", "3.0")
        from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
        import cairo
    except Exception:
        return False

    display_name = ensure_x11_environment()
    if not display_name:
        return False

    ok, _ = Gtk.init_check(sys.argv)
    if not ok:
        return False

    cfg = load_runtime_config()
    entries = scan_desktop_entries()
    presets = discover_icon_and_plasma_presets()
    sys_accent_rgb, sys_accent_label = detect_linux_system_accent_color()
    items = build_dock_items_catalog(cfg, entries)

    libX11 = None
    dpy_ptr = None
    root_xid = 0
    scr_num = 0
    try:
        libX11, _, _, _, _ = load_native_libraries()
        dpy_ptr = libX11.XOpenDisplay(display_name.encode("utf-8")) or libX11.XOpenDisplay(None)
        if dpy_ptr:
            scr_num = libX11.XDefaultScreen(dpy_ptr)
            root_xid = libX11.XRootWindow(dpy_ptr, scr_num)
    except Exception:
        pass

    def get_active_icon_theme():
        preset = cfg.get("icon_preset", "auto")
        if preset and preset.startswith("icons:"):
            tname = preset.split(":", 1)[1]
            custom_theme = Gtk.IconTheme.new()
            custom_theme.set_custom_theme(tname)
            return custom_theme
        return Gtk.IconTheme.get_default()

    def load_single_item_pixbuf(it, target_px=96):
        preset = cfg.get("icon_preset", "auto")
        icon_theme = get_active_icon_theme()
        pb = None
        iname = it.get("icon_name")
        ipath = resolve_icon_path(iname, preset)
        if ipath:
            it["icon_path"] = ipath
        else:
            ipath = it.get("icon_path")

        # 1. When a specific preset (plasma:, icons:, or custom:) is selected, prioritize the resolved file on disk!
        if preset != "auto" and ipath and os.path.isfile(ipath):
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(ipath, target_px, target_px, True)
            except Exception:
                pb = None

        # 2. Try Gtk.IconTheme lookup
        if pb is None and iname and icon_theme:
            try:
                pb = icon_theme.load_icon(iname, target_px, Gtk.IconLookupFlags.FORCE_SIZE)
            except Exception:
                pb = None

        # 3. Try direct file path
        if pb is None and ipath and os.path.isfile(ipath):
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(ipath, target_px, target_px, True)
            except Exception:
                pb = None

        # 4. If running window has X11 _NET_WM_ICON, extract it directly from X11!
        if pb is None and it.get("xids") and libX11 and dpy_ptr:
            pb = extract_x11_net_wm_icon_pixbuf(libX11, dpy_ptr, it["xids"][0], GdkPixbuf)

        it["pixbuf"] = pb

    def reload_all_item_pixbufs(target_px=96):
        for it in items:
            load_single_item_pixbuf(it, target_px)

    reload_all_item_pixbufs(96)

    win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
    win.set_title("Urdocks")
    win.set_wmclass("urdocks", "Urdocks")
    win.set_decorated(False)
    win.set_resizable(False)
    win.set_app_paintable(True)
    win.set_accept_focus(False)
    win.set_focus_on_map(False)
    win.set_skip_taskbar_hint(True)
    win.set_skip_pager_hint(True)
    win.set_keep_above(True)
    win.stick()
    win.set_type_hint(Gdk.WindowTypeHint.DOCK)

    screen = win.get_screen()
    rgba_visual = screen.get_rgba_visual()
    is_composited = screen.is_composited() and (rgba_visual is not None)
    if rgba_visual is not None:
        win.set_visual(rgba_visual)

    # Refresh accent color with live GTK widget StyleContext
    sys_accent_rgb, sys_accent_label = detect_linux_system_accent_color(win)

    win.add_events(
        Gdk.EventMask.POINTER_MOTION_MASK
        | Gdk.EventMask.LEAVE_NOTIFY_MASK
        | Gdk.EventMask.ENTER_NOTIFY_MASK
        | Gdk.EventMask.BUTTON_PRESS_MASK
        | Gdk.EventMask.BUTTON_RELEASE_MASK
        | Gdk.EventMask.SCROLL_MASK
        | Gdk.EventMask.EXPOSURE_MASK
    )

    state = {
        "pointer_x": None,
        "smooth_pointer_x": None,
        "pointer_y": None,
        "scales": [1.0 for _ in items],
        "target_scales": [1.0 for _ in items],
        "item_rects": [],
        "shelf_box": (0, 0, 600, 64),
        "win_x": 0,
        "win_y": 0,
        "win_w": 920,
        "win_h": 175,
        "prefs_win": None,
        "showing_desktop": False,
        "menu_open": False,
        "autohide_progress": 0.0,   # 0.0 = fully visible, 1.0 = hidden off-edge
        "autohide_target": 0.0,
        "last_leave_time": time.time(),
        "sys_accent_rgb": sys_accent_rgb,
        "sys_accent_label": sys_accent_label,
    }

    def on_style_updated(_widget):
        rgb, lbl = detect_linux_system_accent_color(win)
        state["sys_accent_rgb"] = rgb
        state["sys_accent_label"] = lbl
        win.queue_draw()

    win.connect("style-updated", on_style_updated)

    def get_active_accent_rgb():
        if cfg.get("follow_system_accent", True):
            return state["sys_accent_rgb"]
        c = cfg.get("custom_accent_rgb", [0.18, 0.70, 0.60])
        return (float(c[0]), float(c[1]), float(c[2]))

    def get_monitor_workarea():
        dpy = Gdk.Display.get_default()
        if hasattr(dpy, "get_primary_monitor"):
            mon = dpy.get_primary_monitor() or (dpy.get_monitor(0) if dpy.get_n_monitors() > 0 else None)
            if mon:
                wa = mon.get_workarea()
                return wa.x, wa.y, wa.width, wa.height
        sw = screen.get_width()
        sh = screen.get_height()
        return 0, 0, sw, sh

    def reposition_dock_window():
        wx, wy, ww, wh = get_monitor_workarea()
        base_sz = int(cfg["icon_size"])
        spacing = int(cfg["icon_spacing"])
        max_scale = float(cfg["zoom_max_scale"]) if cfg["zoom_enabled"] else 1.0
        n = max(1, len(items))
        max_main = int(n * base_sz * max_scale + (n - 1) * spacing + 150)
        win_w = min(ww - 16, max(560, max_main))
        win_h = int(base_sz * max_scale + 78)
        state["win_w"] = win_w
        state["win_h"] = win_h

        win.set_size_request(win_w, win_h)
        win.resize(win_w, win_h)

        pos = cfg.get("position", "bottom")
        margin = int(cfg.get("margin_px", 6))
        if pos == "top":
            target_x = wx + (ww - win_w) // 2
            target_y = wy + margin
        else:
            target_x = wx + (ww - win_w) // 2
            target_y = wy + wh - win_h - margin

        state["win_x"] = target_x
        state["win_y"] = target_y
        win.move(target_x, target_y)
        win.set_keep_above(True)

    def sync_live_running_windows():
        if not libX11 or not dpy_ptr:
            return True

        active_xid, live_wins = query_live_x11_running_windows(libX11, dpy_ptr, root_xid)

        for it in items:
            it["running"] = False
            it["focused"] = False
            it["xids"] = []
            it["hidden_xids"] = []

        unmatched_groups = {}
        for w in live_wins:
            wmc = w["wm_class"]
            wmc_parts = [p.strip().lower() for p in wmc.split("|") if p.strip()]
            matched_item = None
            for it in items:
                if it.get("is_applet"):
                    continue
                it_stem = it["id"].replace(".desktop", "").lower()
                it_desk_stem = (it.get("desktop_id") or "").replace(".desktop", "").lower()
                it_wmc = (it.get("wm_class") or "").lower()
                it_exec = os.path.basename(it["exec"].split()[0]).lower() if it.get("exec") else ""
                for p in wmc_parts:
                    if (
                        p == it_stem
                        or p == it_desk_stem
                        or it_stem.endswith("." + p)
                        or (it_wmc and (p == it_wmc or p in it_wmc.lower()))
                        or (it_exec and p == it_exec)
                    ):
                        matched_item = it
                        break
                if matched_item:
                    break

            if matched_item is not None:
                matched_item["running"] = True
                matched_item["xids"].append(w["xid"])
                if w.get("is_hidden"):
                    matched_item["hidden_xids"].append(w["xid"])
                if w["xid"] == active_xid and not w.get("is_hidden"):
                    matched_item["focused"] = True
            elif cfg.get("show_unpinned_running", True):
                group_key = wmc_parts[-1] if wmc_parts else w["title"]
                if group_key not in unmatched_groups:
                    unmatched_groups[group_key] = {
                        "wm_class": wmc,
                        "title": w["title"],
                        "xids": [],
                        "hidden_xids": [],
                        "focused": False,
                    }
                unmatched_groups[group_key]["xids"].append(w["xid"])
                if w.get("is_hidden"):
                    unmatched_groups[group_key]["hidden_xids"].append(w["xid"])
                if w["xid"] == active_xid and not w.get("is_hidden"):
                    unmatched_groups[group_key]["focused"] = True

        changed_layout = False
        keep_items = []
        keep_scales = []
        keep_targets = []
        for idx, it in enumerate(items):
            if not it.get("pinned", True) and not it.get("is_applet", False) and not it["running"]:
                changed_layout = True
                continue
            keep_items.append(it)
            keep_scales.append(state["scales"][idx] if idx < len(state["scales"]) else 1.0)
            keep_targets.append(state["target_scales"][idx] if idx < len(state["target_scales"]) else 1.0)

        if changed_layout:
            items[:] = keep_items
            state["scales"] = keep_scales
            state["target_scales"] = keep_targets

        if cfg.get("show_unpinned_running", True) and unmatched_groups:
            insert_pos = max(1, len(items) - 3)
            for gkey, ginfo in unmatched_groups.items():
                ent = match_window_to_desktop_entry(ginfo["wm_class"], entries)
                if ent:
                    new_id = ent["id"]
                    new_name = ent["name"]
                    new_exec = ent["exec"]
                    new_icon = ent["icon"]
                    new_wmc = ent.get("wm_class", ginfo["wm_class"])
                else:
                    new_id = f"{gkey}.desktop"
                    new_name = ginfo["title"][:28] or gkey.capitalize()
                    new_exec = gkey
                    new_icon = gkey
                    new_wmc = ginfo["wm_class"]

                new_item = {
                    "id": new_id,
                    "desktop_id": new_id,
                    "name": new_name,
                    "exec": new_exec,
                    "icon_name": new_icon,
                    "icon_path": resolve_icon_path(new_icon, cfg.get("icon_preset", "auto")),
                    "wm_class": new_wmc,
                    "glyph": "doc",
                    "rgb": get_active_accent_rgb(),
                    "pinned": False,
                    "is_applet": False,
                    "running": True,
                    "focused": ginfo["focused"],
                    "xids": ginfo["xids"],
                    "hidden_xids": ginfo["hidden_xids"],
                    "bounce_t": time.time(),
                    "shrink_t": 0.0,
                    "entry_scale": 0.15,
                }
                load_single_item_pixbuf(new_item, 96)
                items.insert(insert_pos, new_item)
                state["scales"].insert(insert_pos, 0.25)
                state["target_scales"].insert(insert_pos, 1.0)
                insert_pos += 1
                changed_layout = True

        if changed_layout:
            reposition_dock_window()
        win.queue_draw()
        return True

    def draw_rounded_rect_cairo(cr, x, y, w, h, r):
        r = min(r, w * 0.5, h * 0.5)
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi * 0.5, 0.0)
        cr.arc(x + w - r, y + h - r, r, 0.0, math.pi * 0.5)
        cr.arc(x + r, y + h - r, r, math.pi * 0.5, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
        cr.close_path()

    def draw_apple_superellipse_capsule_cairo(cr, x, y, w, h):
        """
        Draws an Apple continuous-curve superellipse (squircle) capsule tooltip.
        Instead of a circular arc that breaks curvature at the tangent point, this
        uses extended cubic Bézier splines (G2 continuous transition) from the
        straight horizontal edge into the smooth capsule end-caps.
        """
        r = min(h * 0.5, w * 0.5)
        ext = min(w * 0.46, r * 1.38)
        c1 = ext * 0.52
        c2 = r * 0.94

        cr.new_sub_path()
        # Top straight edge
        cr.move_to(x + ext, y)
        cr.line_to(x + w - ext, y)
        # Top-right continuous squircle curve into right capsule apex
        cr.curve_to(x + w - c1, y, x + w, y + (r - c2), x + w, y + r)
        # Bottom-right continuous squircle curve back to bottom straight edge
        cr.curve_to(x + w, y + h - (r - c2), x + w - c1, y + h, x + w - ext, y + h)
        # Bottom straight edge
        cr.line_to(x + ext, y + h)
        # Bottom-left continuous squircle curve into left capsule apex
        cr.curve_to(x + c1, y + h, x, y + h - (r - c2), x, y + r)
        # Top-left continuous squircle curve back to top straight edge
        cr.curve_to(x, y + (r - c2), x + c1, y, x + ext, y)
        cr.close_path()

    def draw_fallback_glyph_cairo(cr, glyph, ix, iy, sz):
        cx = ix + sz * 0.5
        cy = iy + sz * 0.5
        cr.set_line_width(max(1.8, sz * 0.055))
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.95)
        if glyph == "launcher":
            g = sz * 0.16
            gap = sz * 0.06
            for r in (-1, 1):
                for c in (-1, 1):
                    draw_rounded_rect_cairo(
                        cr,
                        cx + c * (g * 0.5 + gap) - g * 0.5,
                        cy + r * (g * 0.5 + gap) - g * 0.5,
                        g,
                        g,
                        g * 0.28,
                    )
                    cr.fill()
        elif glyph == "terminal":
            cr.move_to(cx - sz * 0.20, cy - sz * 0.12)
            cr.line_to(cx - sz * 0.04, cy)
            cr.line_to(cx - sz * 0.20, cy + sz * 0.12)
            cr.move_to(cx + sz * 0.02, cy + sz * 0.14)
            cr.line_to(cx + sz * 0.20, cy + sz * 0.14)
            cr.stroke()
        else:
            w = sz * 0.42
            h = sz * 0.36
            draw_rounded_rect_cairo(cr, cx - w * 0.5, cy - h * 0.5, w, h, 4.0)
            cr.stroke()

    def on_draw(widget, cr):
        win_w = widget.get_allocated_width()
        win_h = widget.get_allocated_height()
        is_comp = screen.is_composited() and (rgba_visual is not None)

        cr.save()
        if is_comp:
            cr.set_operator(cairo.OPERATOR_CLEAR)
            cr.paint()
            cr.set_operator(cairo.OPERATOR_OVER)
        else:
            cr.set_source_rgb(0.08, 0.10, 0.15)
            cr.paint()
        cr.restore()

        base_size = float(cfg["icon_size"])
        spacing = float(cfg["icon_spacing"])
        shelf_pad_x = 14.0
        shelf_pad_y = 8.0
        pos = cfg.get("position", "bottom")
        accent_r, accent_g, accent_b = get_active_accent_rgb()
        frost = max(0.0, min(1.0, float(cfg.get("frosted_glass", 0.28))))
        theme_idx = int(cfg.get("theme_idx", 0)) % len(THEMES)
        is_liquid_glass = (theme_idx == 0)

        sizes = [
            base_size * state["scales"][i] * items[i].get("entry_scale", 1.0)
            for i in range(len(items))
        ]
        total_icons_w = sum(sizes) + spacing * max(0, len(items) - 1)
        shelf_w = total_icons_w + shelf_pad_x * 2.0
        shelf_h = base_size + shelf_pad_y * 2.0
        shelf_x = (win_w - shelf_w) * 0.5

        # Smooth autohide slide offset
        hide_shift = state["autohide_progress"] * (shelf_h + 18.0)
        if pos == "top":
            shelf_y = 6.0 - hide_shift
        else:
            shelf_y = (win_h - 6.0 - shelf_h) + hide_shift

        state["shelf_box"] = (shelf_x, shelf_y, shelf_w, shelf_h)
        _, bg_rgba, spec_rgba = THEMES[theme_idx]

        # Outer soft shadow
        if is_comp and state["autohide_progress"] < 0.98:
            draw_rounded_rect_cairo(cr, shelf_x - 2.0, shelf_y + 3.0, shelf_w + 4.0, shelf_h + 2.0, 20.0)
            shadow_alpha = (0.18 + frost * 0.20) if is_liquid_glass else 0.32
            cr.set_source_rgba(0.0, 0.0, 0.0, shadow_alpha * (1.0 - state["autohide_progress"]))
            cr.fill()

        # Glassmorphism / Liquid Glass shelf body modulated by Frosted Glass slider
        draw_rounded_rect_cairo(cr, shelf_x, shelf_y, shelf_w, shelf_h, 18.0)
        if is_liquid_glass:
            # Clear Liquid Glass at frost=0.0 -> Deep Frosted Glass at frost=1.0
            clear_alpha = 0.06 + frost * 0.72
            r_fill = 0.12 * (1.0 - frost) + 0.88 * frost
            g_fill = 0.16 * (1.0 - frost) + 0.93 * frost
            b_fill = 0.24 * (1.0 - frost) + 0.99 * frost
            cr.set_source_rgba(r_fill, g_fill, b_fill, clear_alpha)
            cr.fill_preserve()

            # Liquid Glass refractive top-to-bottom sheen gradient
            grad = cairo.LinearGradient(shelf_x, shelf_y, shelf_x, shelf_y + shelf_h)
            grad.add_color_stop_rgba(0.0, 1.0, 1.0, 1.0, 0.34 + frost * 0.24)
            grad.add_color_stop_rgba(0.42, accent_r, accent_g, accent_b, 0.05 + frost * 0.12)
            grad.add_color_stop_rgba(1.0, 0.05, 0.08, 0.14, 0.12 + frost * 0.28)
            cr.set_source(grad)
            cr.fill_preserve()
        else:
            eff_alpha = max(0.12, min(0.96, bg_rgba[3] * (0.55 + frost * 0.65)))
            cr.set_source_rgba(bg_rgba[0], bg_rgba[1], bg_rgba[2], eff_alpha)
            cr.fill_preserve()

        cr.set_line_width(1.0)
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.32 if is_liquid_glass else 0.18)
        cr.stroke()

        # Inner 1.2px specular refractive rim tinted with active Linux system accent color
        draw_rounded_rect_cairo(cr, shelf_x + 1.0, shelf_y + 1.0, shelf_w - 2.0, shelf_h - 2.0, 17.0)
        cr.set_line_width(1.2 if is_liquid_glass else 1.0)
        if cfg.get("follow_system_accent", True):
            cr.set_source_rgba(
                accent_r * 0.60 + spec_rgba[0] * 0.40,
                accent_g * 0.60 + spec_rgba[1] * 0.40,
                accent_b * 0.60 + spec_rgba[2] * 0.40,
                0.62 if is_liquid_glass else 0.46,
            )
        else:
            cr.set_source_rgba(spec_rgba[0], spec_rgba[1], spec_rgba[2], spec_rgba[3])
        cr.stroke()

        cur_x = shelf_x + shelf_pad_x
        hovered_idx = None
        if state["pointer_x"] is not None and state["autohide_progress"] < 0.3:
            best_s = 1.01
            for idx, s in enumerate(state["scales"]):
                if s > best_s:
                    best_s = s
                    hovered_idx = idx

        rects = []
        now = time.time()
        for idx, item in enumerate(items):
            # Draw subtle vertical divider before unpinned running section or before applets
            if idx > 0:
                prev = items[idx - 1]
                need_sep = (
                    (prev.get("id") == "launcher")
                    or (prev.get("pinned", True) and not item.get("pinned", True))
                    or (not prev.get("is_applet", False) and item.get("is_applet", False) and item.get("id") == "preferences")
                )
                if need_sep:
                    sep_x = cur_x - spacing * 0.5
                    cr.set_line_width(1.0)
                    cr.set_source_rgba(1.0, 1.0, 1.0, 0.24)
                    cr.move_to(sep_x, shelf_y + 10.0)
                    cr.line_to(sep_x, shelf_y + shelf_h - 10.0)
                    cr.stroke()

            sz = sizes[idx]
            ix = cur_x

            bounce_px = 0.0
            dt = now - item.get("bounce_t", 0.0)
            if 0.0 < dt < 0.65:
                bounce_px = abs(math.sin(dt * math.pi * 3.2)) * math.exp(-dt * 3.5) * 18.0

            # Shrink-into-icon absorption pulse when minimizing an open window
            shrink_scale = 1.0
            dt_shrink = now - item.get("shrink_t", 0.0)
            if 0.0 < dt_shrink < 0.42:
                shrink_scale = 1.0 - 0.24 * math.sin((dt_shrink / 0.42) * math.pi)

            if pos == "top":
                iy = shelf_y + shelf_pad_y + bounce_px
            else:
                iy = (shelf_y + shelf_h - shelf_pad_y) - sz - bounce_px

            rects.append((ix, iy, sz, sz, item))

            # Update X11 _NET_WM_ICON_GEOMETRY on all open windows of this item so Linux WM shrinks to this icon
            if item.get("xids") and libX11 and dpy_ptr:
                root_ix = state["win_x"] + int(ix)
                root_iy = state["win_y"] + int(iy)
                last_geom = item.get("_last_icon_geom")
                cur_geom = (root_ix, root_iy, int(sz), int(sz))
                if last_geom != cur_geom:
                    item["_last_icon_geom"] = cur_geom
                    for xid in item["xids"]:
                        set_x11_window_icon_geometry(libX11, dpy_ptr, xid, root_ix, root_iy, int(sz), int(sz))

            draw_sz = sz * shrink_scale
            draw_ix = ix + (sz - draw_sz) * 0.5
            draw_iy = iy + (sz - draw_sz) * 0.5

            pb = item.get("pixbuf")
            if pb is not None and draw_sz > 2.0:
                cr.save()
                pw = pb.get_width()
                ph = pb.get_height()
                sx = draw_sz / float(pw)
                sy = draw_sz / float(ph)
                cr.translate(draw_ix, draw_iy)
                cr.scale(sx, sy)
                Gdk.cairo_set_source_pixbuf(cr, pb, 0.0, 0.0)
                cr.paint()
                cr.restore()

                if cfg.get("icon_reflection", True) and pos == "bottom":
                    cr.save()
                    cr.translate(draw_ix, draw_iy + draw_sz + 2.0)
                    cr.scale(sx, sy * 0.22)
                    Gdk.cairo_set_source_pixbuf(cr, pb, 0.0, 0.0)
                    cr.paint_with_alpha(0.18)
                    cr.restore()
            elif draw_sz > 2.0:
                r, g, b = item["rgb"]
                draw_rounded_rect_cairo(cr, draw_ix, draw_iy, draw_sz, draw_sz, draw_sz * 0.24)
                cr.set_source_rgba(r, g, b, 0.95)
                cr.fill_preserve()
                cr.set_line_width(1.0)
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.35)
                cr.stroke()
                draw_fallback_glyph_cairo(cr, item.get("glyph", "doc"), draw_ix, draw_iy, draw_sz)

            # Running / Focused Indicator Dot colored with Active Linux System Accent
            if cfg.get("show_indicator_dots", True) and item.get("running", False):
                dot_x = ix + sz * 0.5
                dot_y = (shelf_y + 3.5) if pos == "top" else (shelf_y + shelf_h - 3.5)
                if item.get("focused", False):
                    draw_rounded_rect_cairo(cr, dot_x - 5.5, dot_y - 2.0, 11.0, 4.0, 2.0)
                    cr.set_source_rgba(accent_r, accent_g, accent_b, 1.0)
                    cr.fill()
                else:
                    cr.new_sub_path()
                    cr.arc(dot_x, dot_y, 2.4, 0.0, 2.0 * math.pi)
                    cr.set_source_rgba(accent_r, accent_g, accent_b, 0.92)
                    cr.fill()

            # v3.0 Hover Tooltip with Apple Continuous-Curve Superellipse (Squircle) Capsule
            if hovered_idx == idx:
                label = item["name"]
                if not item.get("is_applet") and not item.get("pinned", True):
                    label = f"{item['name']} (Sedang Dibuka • Klik Kanan: Pin di Dock)"
                elif item["id"] == "trash":
                    tcnt = get_trash_file_count()
                    label = f"Trash ({tcnt} items)" if tcnt > 0 else "Trash (Empty)"
                cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
                cr.set_font_size(12.5)
                ext = cr.text_extents(label)
                tw = max(78.0, ext.width + 30.0)
                th = 28.0
                tx = max(4.0, min(win_w - tw - 4.0, ix + sz * 0.5 - tw * 0.5))
                ty = (iy + sz + 10.0) if pos == "top" else max(2.0, iy - th - 10.0)

                draw_apple_superellipse_capsule_cairo(cr, tx, ty, tw, th)
                if is_liquid_glass:
                    cr.set_source_rgba(0.08, 0.11, 0.18, 0.68 + frost * 0.26)
                else:
                    cr.set_source_rgba(0.07, 0.09, 0.14, 0.94)
                cr.fill_preserve()
                cr.set_line_width(1.1)
                cr.set_source_rgba(accent_r, accent_g, accent_b, 0.78)
                cr.stroke()

                cr.set_source_rgba(0.97, 0.99, 1.0, 1.0)
                cr.move_to(tx + (tw - ext.width) * 0.5, ty + 18.0)
                cr.show_text(label)

            cur_x += sz + spacing

        state["item_rects"] = rects

        # Update XShape click-through region
        try:
            if state["autohide_progress"] > 0.85:
                trig_y = 0 if pos == "top" else max(0, win_h - 6)
                rect_list = [
                    cairo.RectangleInt(max(0, int(shelf_x)), trig_y, int(shelf_w), 6)
                ]
            else:
                rect_list = [
                    cairo.RectangleInt(
                        max(0, int(shelf_x) - 2),
                        max(0, int(shelf_y) - 2),
                        int(shelf_w) + 4,
                        int(shelf_h) + 4,
                    )
                ]
                for rx, ry, rw, rh, _ in rects:
                    rect_list.append(
                        cairo.RectangleInt(
                            max(0, int(rx) - 2),
                            max(0, int(ry) - 2),
                            int(rw) + 4,
                            int(rh) + 4,
                        )
                    )
            region = cairo.Region(rect_list)
            if is_comp:
                widget.input_shape_combine_region(region)
                widget.shape_combine_region(None)
            else:
                widget.shape_combine_region(region)
        except Exception:
            pass

        return False

    def check_global_pointer_for_autohide():
        if not cfg.get("autohide", False) or state["menu_open"] or state["prefs_win"] is not None:
            state["autohide_target"] = 0.0
            return

        try:
            dpy = Gdk.Display.get_default()
            seat = dpy.get_default_seat()
            ptr = seat.get_pointer()
            _, gx, gy = ptr.get_position()
            wx, wy = state["win_x"], state["win_y"]
            ww, wh = state["win_w"], state["win_h"]
            sx, sy, sw, sh = state["shelf_box"]
            pos = cfg.get("position", "bottom")

            in_x = (wx + sx - 28) <= gx <= (wx + sx + sw + 28)
            if state["autohide_progress"] > 0.5:
                if pos == "top":
                    near_edge = gy <= (wy + 14)
                else:
                    near_edge = gy >= (wy + wh - 16)
                if in_x and near_edge:
                    state["autohide_target"] = 0.0
                    state["pointer_x"] = float(gx - wx)
                else:
                    state["autohide_target"] = 1.0
            else:
                if pos == "top":
                    in_y = gy <= (wy + sy + sh + 40)
                else:
                    in_y = gy >= (wy + sy - 46)
                if in_x and in_y:
                    state["autohide_target"] = 0.0
                    state["last_leave_time"] = time.time()
                else:
                    if time.time() - state["last_leave_time"] > 0.24:
                        state["autohide_target"] = 1.0
                        state["pointer_x"] = None
        except Exception:
            state["autohide_target"] = 0.0

    def recompute_target_scales():
        raw_px = state["pointer_x"]
        if raw_px is not None:
            if state["smooth_pointer_x"] is None:
                state["smooth_pointer_x"] = raw_px
            else:
                state["smooth_pointer_x"] += (raw_px - state["smooth_pointer_x"]) * 0.45
        else:
            state["smooth_pointer_x"] = None

        px = state["smooth_pointer_x"]
        base_size = float(cfg["icon_size"])
        spacing = float(cfg["icon_spacing"])
        max_scale = float(cfg["zoom_max_scale"]) if cfg.get("zoom_enabled", True) else 1.0
        range_px = base_size * float(cfg.get("zoom_range_icons", 3.0))

        unscaled_w = len(items) * base_size + max(0, len(items) - 1) * spacing
        track_start = (state["win_w"] - unscaled_w) * 0.5

        for i in range(len(items)):
            center_x = track_start + i * (base_size + spacing) + base_size * 0.5
            if px is not None and state["autohide_target"] < 0.5:
                dist = abs(px - center_x)
                if dist < range_px:
                    w = 0.5 * (1.0 + math.cos(math.pi * dist / range_px))
                    state["target_scales"][i] = 1.0 + (max_scale - 1.0) * w
                else:
                    state["target_scales"][i] = 1.0
            else:
                state["target_scales"][i] = 1.0

    def tick_physics():
        check_global_pointer_for_autohide()
        recompute_target_scales()
        changed = False
        now = time.time()

        # Smooth 60 FPS autohide interpolation
        ah_diff = state["autohide_target"] - state["autohide_progress"]
        if abs(ah_diff) > 0.002:
            state["autohide_progress"] += ah_diff * 0.20
            changed = True
        else:
            state["autohide_progress"] = state["autohide_target"]

        for i in range(len(items)):
            diff = state["target_scales"][i] - state["scales"][i]
            if abs(diff) > 0.0015:
                state["scales"][i] += diff * 0.28
                changed = True
            else:
                state["scales"][i] = state["target_scales"][i]

            es = items[i].get("entry_scale", 1.0)
            if es < 0.998:
                items[i]["entry_scale"] = es + (1.0 - es) * 0.22
                changed = True
            else:
                items[i]["entry_scale"] = 1.0

            if now - items[i].get("bounce_t", 0.0) < 0.70 or now - items[i].get("shrink_t", 0.0) < 0.45:
                changed = True

        if changed:
            win.queue_draw()
        return True

    def toggle_pin_item(item, should_pin):
        if item.get("is_applet"):
            return
        desk_id = item.get("desktop_id") or item["id"]
        pinned_list = list(cfg.get("pinned_apps", DEFAULT_PINNED_IDS))
        custom_meta = dict(cfg.get("pinned_custom_meta", {}))

        if should_pin:
            item["pinned"] = True
            if desk_id not in pinned_list and item["id"] not in pinned_list:
                pinned_list.append(item["id"])
            custom_meta[item["id"]] = {
                "name": item.get("name", item["id"]),
                "exec": item.get("exec", item["id"]),
                "icon_name": item.get("icon_name", item["id"]),
                "wm_class": item.get("wm_class", ""),
            }
        else:
            item["pinned"] = False
            pinned_list = [x for x in pinned_list if x != desk_id and x != item["id"]]
            custom_meta.pop(item["id"], None)
            custom_meta.pop(desk_id, None)

        cfg["pinned_apps"] = pinned_list
        cfg["pinned_custom_meta"] = custom_meta
        save_runtime_config(cfg)
        sync_live_running_windows()
        win.queue_draw()

    def apply_icon_preset(preset_id):
        cfg["icon_preset"] = preset_id
        save_runtime_config(cfg)
        reload_all_item_pixbufs(96)
        win.queue_draw()

    def choose_custom_theme_directory(parent_win=None):
        dlg = Gtk.FileChooserDialog(
            title="Pilih Folder Tema Icon (~/.local/share/plasma/desktoptheme atau /usr/share/icons)",
            parent=parent_win or win,
            action=Gtk.FileChooserAction.SELECT_FOLDER,
        )
        dlg.add_buttons(
            Gtk.STOCK_CANCEL,
            Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN,
            Gtk.ResponseType.OK,
        )
        plasma_default = os.path.expanduser("~/.local/share/plasma/desktoptheme")
        if os.path.isdir(plasma_default):
            dlg.set_current_folder(plasma_default)
        else:
            dlg.set_current_folder("/usr/share/icons")
        resp = dlg.run()
        chosen = dlg.get_filename()
        dlg.destroy()
        if resp == Gtk.ResponseType.OK and chosen and os.path.isdir(chosen):
            apply_icon_preset(f"custom:{chosen}")

    def open_preferences_window():
        if state["prefs_win"] is not None:
            state["prefs_win"].present()
            return

        pwin = Gtk.Window(title="Urdocks v3.0.0 — Dock Preferences & Changelog")
        pwin.set_default_size(540, 610)
        pwin.set_position(Gtk.WindowPosition.CENTER)
        pwin.set_keep_above(True)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        vbox.set_margin_top(16)
        vbox.set_margin_bottom(16)
        vbox.set_margin_start(18)
        vbox.set_margin_end(18)
        pwin.add(vbox)

        hdr = Gtk.Label()
        hdr.set_markup("<b>Urdocks v3.0.0 — Visual Dock Preferences</b>")
        hdr.set_xalign(0.0)
        vbox.pack_start(hdr, False, False, 0)

        # 1. Icon Theme / Plasma Desktoptheme Preset Selector
        row_icon = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        lbl_icon = Gtk.Label(label="Icon Preset (Plasma / Icons):")
        lbl_icon.set_xalign(0.0)
        combo_icon = Gtk.ComboBoxText()
        active_preset_idx = 0
        for idx, (pid, plabel, _, _) in enumerate(presets):
            combo_icon.append_text(plabel)
            if pid == cfg.get("icon_preset", "auto"):
                active_preset_idx = idx
        combo_icon.set_active(active_preset_idx)

        def on_icon_preset_changed(cb):
            idx = cb.get_active()
            if 0 <= idx < len(presets):
                apply_icon_preset(presets[idx][0])

        combo_icon.connect("changed", on_icon_preset_changed)
        btn_browse = Gtk.Button(label="Pilih Folder...")
        btn_browse.connect("clicked", lambda _: choose_custom_theme_directory(pwin))
        row_icon.pack_start(lbl_icon, True, True, 0)
        row_icon.pack_end(btn_browse, False, False, 0)
        row_icon.pack_end(combo_icon, False, False, 0)
        vbox.pack_start(row_icon, False, False, 0)

        # 2. Shelf Glass Theme Combo (Includes Liquid Glass preset!)
        row_theme = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lbl_theme = Gtk.Label(label="Shelf Glass Theme (Liquid Glass):")
        lbl_theme.set_xalign(0.0)
        combo_theme = Gtk.ComboBoxText()
        for tname, _, _ in THEMES:
            combo_theme.append_text(tname)
        combo_theme.set_active(int(cfg.get("theme_idx", 0)) % len(THEMES))

        def on_theme_changed(cb):
            cfg["theme_idx"] = cb.get_active()
            save_runtime_config(cfg)
            win.queue_draw()

        combo_theme.connect("changed", on_theme_changed)
        row_theme.pack_start(lbl_theme, True, True, 0)
        row_theme.pack_end(combo_theme, False, False, 0)
        vbox.pack_start(row_theme, False, False, 0)

        # 2b. v3.0 Frosted Glass Slider (0% Clear Glass -> 100% Frosted Glass)
        frost_pct = int(round(float(cfg.get("frosted_glass", 0.28)) * 100))
        lbl_frost = Gtk.Label(
            label=f"Frosted Glass Slider ({frost_pct}% — 0% Clear Glass .. 100% Frosted):"
        )
        lbl_frost.set_xalign(0.0)
        vbox.pack_start(lbl_frost, False, False, 0)
        scale_frost = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 2)
        scale_frost.set_value(frost_pct)

        def on_frost_changed(sc):
            pct = int(sc.get_value())
            cfg["frosted_glass"] = round(pct / 100.0, 2)
            lbl_frost.set_text(
                f"Frosted Glass Slider ({pct}% — 0% Clear Glass .. 100% Frosted):"
            )
            save_runtime_config(cfg)
            win.queue_draw()

        scale_frost.connect("value-changed", on_frost_changed)
        vbox.pack_start(scale_frost, False, False, 0)

        # 3. Position Combo
        row_pos = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lbl_pos = Gtk.Label(label="Screen Edge:")
        lbl_pos.set_xalign(0.0)
        combo_pos = Gtk.ComboBoxText()
        for p in ("bottom", "top"):
            combo_pos.append_text(p.capitalize())
        combo_pos.set_active(1 if cfg.get("position") == "top" else 0)

        def on_pos_changed(cb):
            cfg["position"] = "top" if cb.get_active() == 1 else "bottom"
            save_runtime_config(cfg)
            reposition_dock_window()
            win.queue_draw()

        combo_pos.connect("changed", on_pos_changed)
        row_pos.pack_start(lbl_pos, True, True, 0)
        row_pos.pack_end(combo_pos, False, False, 0)
        vbox.pack_start(row_pos, False, False, 0)

        # 4. Checkboxes for v3.0 & v2.1 features
        chk_minimize = Gtk.CheckButton(
            label="Klik Aplikasi yang Sedang Terbuka untuk Minimize & Shrink ke Ikon Dock"
        )
        chk_minimize.set_active(bool(cfg.get("click_to_minimize", True)))
        def on_minimize_toggled(btn):
            cfg["click_to_minimize"] = btn.get_active()
            save_runtime_config(cfg)
        chk_minimize.connect("toggled", on_minimize_toggled)
        vbox.pack_start(chk_minimize, False, False, 0)

        chk_accent = Gtk.CheckButton(
            label=f"Ikuti Aksen Warna Sistem Linux ({state['sys_accent_label']})"
        )
        chk_accent.set_active(bool(cfg.get("follow_system_accent", True)))
        def on_accent_toggled(btn):
            cfg["follow_system_accent"] = btn.get_active()
            save_runtime_config(cfg)
            win.queue_draw()
        chk_accent.connect("toggled", on_accent_toggled)
        vbox.pack_start(chk_accent, False, False, 0)

        chk_autohide = Gtk.CheckButton(
            label="Autohide saat mouse tidak di area dock (Smooth Slide)"
        )
        chk_autohide.set_active(bool(cfg.get("autohide", False)))
        def on_autohide_toggled(btn):
            cfg["autohide"] = btn.get_active()
            save_runtime_config(cfg)
            win.queue_draw()
        chk_autohide.connect("toggled", on_autohide_toggled)
        vbox.pack_start(chk_autohide, False, False, 0)

        chk_running = Gtk.CheckButton(
            label="Otomatis tampilkan aplikasi yang sedang / baru dibuka (_NET_CLIENT_LIST)"
        )
        chk_running.set_active(bool(cfg.get("show_unpinned_running", True)))
        def on_running_toggled(btn):
            cfg["show_unpinned_running"] = btn.get_active()
            save_runtime_config(cfg)
            sync_live_running_windows()
        chk_running.connect("toggled", on_running_toggled)
        vbox.pack_start(chk_running, False, False, 0)

        # 5. Icon Size Scale
        lbl_sz = Gtk.Label(label=f"Icon Size ({int(cfg['icon_size'])} px):")
        lbl_sz.set_xalign(0.0)
        vbox.pack_start(lbl_sz, False, False, 0)
        scale_sz = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 32, 72, 2)
        scale_sz.set_value(cfg["icon_size"])

        def on_sz_changed(sc):
            val = int(sc.get_value())
            cfg["icon_size"] = val
            lbl_sz.set_text(f"Icon Size ({val} px):")
            save_runtime_config(cfg)
            reposition_dock_window()
            win.queue_draw()

        scale_sz.connect("value-changed", on_sz_changed)
        vbox.pack_start(scale_sz, False, False, 0)

        # 6. Zoom Scale
        lbl_zm = Gtk.Label(label=f"Hover Magnification ({cfg['zoom_max_scale']:.2f}x):")
        lbl_zm.set_xalign(0.0)
        vbox.pack_start(lbl_zm, False, False, 0)
        scale_zm = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 1.0, 2.1, 0.05)
        scale_zm.set_value(cfg["zoom_max_scale"])

        def on_zm_changed(sc):
            val = round(float(sc.get_value()), 2)
            cfg["zoom_max_scale"] = val
            cfg["zoom_enabled"] = val > 1.02
            lbl_zm.set_text(f"Hover Magnification ({val:.2f}x):")
            save_runtime_config(cfg)
            reposition_dock_window()
            win.queue_draw()

        scale_zm.connect("value-changed", on_zm_changed)
        vbox.pack_start(scale_zm, False, False, 0)

        # 7. Author Credit Footer: Haris Gitama (github.com/Harisgitama)
        sep_author = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        vbox.pack_start(sep_author, False, False, 4)

        row_author = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lbl_author = Gtk.Label()
        lbl_author.set_markup("<b>Author:</b> Haris Gitama")
        lbl_author.set_xalign(0.0)
        btn_github = Gtk.LinkButton.new_with_label(
            "https://github.com/Harisgitama", "github.com/Harisgitama"
        )
        row_author.pack_start(lbl_author, True, True, 0)
        row_author.pack_end(btn_github, False, False, 0)
        vbox.pack_start(row_author, False, False, 0)

        def on_prefs_destroy(_w):
            state["prefs_win"] = None

        pwin.connect("destroy", on_prefs_destroy)
        state["prefs_win"] = pwin
        pwin.show_all()

    def show_context_menu(event, clicked_item=None):
        state["menu_open"] = True
        menu = Gtk.Menu()
        menu.connect("deactivate", lambda _: state.update({"menu_open": False}))

        if clicked_item:
            action_lbl = (
                f"Minimize (Shrink ke Dock): {clicked_item['name']}"
                if (clicked_item.get("focused") and cfg.get("click_to_minimize", True))
                else f"Buka / Fokus: {clicked_item['name']}"
            )
            title_item = Gtk.MenuItem(label=action_lbl)
            title_item.connect("activate", lambda _: handle_item_activate(clicked_item))
            menu.append(title_item)

            if not clicked_item.get("is_applet", False):
                pin_chk = Gtk.CheckMenuItem(label="Pin di Dock (Keep in Dock)")
                pin_chk.set_active(bool(clicked_item.get("pinned", True)))
                pin_chk.connect(
                    "toggled",
                    lambda chk: toggle_pin_item(clicked_item, chk.get_active()),
                )
                menu.append(pin_chk)

                new_win_item = Gtk.MenuItem(label="Buka Jendela Baru (New Instance)")
                new_win_item.connect("activate", lambda _: launch_command(clicked_item["exec"]))
                menu.append(new_win_item)

            menu.append(Gtk.SeparatorMenuItem())

        preset_menu_item = Gtk.MenuItem(label="Pilih Icon Preset (Plasma & /usr/share/icons)")
        preset_sub = Gtk.Menu()
        cur_preset = cfg.get("icon_preset", "auto")
        for pid, plabel, _, _ in presets[:28]:
            p_chk = Gtk.CheckMenuItem(label=plabel)
            p_chk.set_active(pid == cur_preset)
            p_chk.connect("toggled", lambda _c, target_id=pid: apply_icon_preset(target_id))
            preset_sub.append(p_chk)
        preset_sub.append(Gtk.SeparatorMenuItem())
        browse_item = Gtk.MenuItem(label="Pilih Folder Tema Custom...")
        browse_item.connect("activate", lambda _: choose_custom_theme_directory(win))
        preset_sub.append(browse_item)
        preset_menu_item.set_submenu(preset_sub)
        menu.append(preset_menu_item)

        autohide_chk = Gtk.CheckMenuItem(label="Autohide saat mouse di luar dock")
        autohide_chk.set_active(bool(cfg.get("autohide", False)))
        def _toggle_autohide(chk):
            cfg["autohide"] = chk.get_active()
            save_runtime_config(cfg)
            win.queue_draw()
        autohide_chk.connect("toggled", _toggle_autohide)
        menu.append(autohide_chk)

        accent_chk = Gtk.CheckMenuItem(label=f"Ikuti Aksen Warna Sistem ({state['sys_accent_label']})")
        accent_chk.set_active(bool(cfg.get("follow_system_accent", True)))
        def _toggle_accent(chk):
            cfg["follow_system_accent"] = chk.get_active()
            save_runtime_config(cfg)
            win.queue_draw()
        accent_chk.connect("toggled", _toggle_accent)
        menu.append(accent_chk)

        prefs_item = Gtk.MenuItem(label="Urdocks Preferences (Liquid Glass & Frosted Slider)...")
        prefs_item.connect("activate", lambda _: open_preferences_window())
        menu.append(prefs_item)

        theme_item = Gtk.MenuItem(label="Cycle Shelf Glass Theme (Liquid Glass / Sequoia)")
        def _cycle_theme(_):
            cfg["theme_idx"] = (int(cfg["theme_idx"]) + 1) % len(THEMES)
            save_runtime_config(cfg)
            win.queue_draw()
        theme_item.connect("activate", _cycle_theme)
        menu.append(theme_item)

        pos_item = Gtk.MenuItem(label="Toggle Bottom / Top Edge")
        def _toggle_pos(_):
            cfg["position"] = "top" if cfg.get("position") == "bottom" else "bottom"
            save_runtime_config(cfg)
            reposition_dock_window()
            win.queue_draw()
        pos_item.connect("activate", _toggle_pos)
        menu.append(pos_item)

        author_item = Gtk.MenuItem(label="Author: Haris Gitama (github.com/Harisgitama)")
        author_item.connect("activate", lambda _: launch_command("xdg-open https://github.com/Harisgitama"))
        menu.append(author_item)

        menu.append(Gtk.SeparatorMenuItem())
        quit_item = Gtk.MenuItem(label="Quit Urdocks")
        quit_item.connect("activate", lambda _: Gtk.main_quit())
        menu.append(quit_item)

        menu.show_all()
        menu.popup_at_pointer(event)

    def handle_item_activate(item):
        win.queue_draw()
        if item["exec"] == "__open_preferences__":
            item["bounce_t"] = time.time()
            open_preferences_window()
        elif item["exec"] == "__toggle_desktop__":
            item["bounce_t"] = time.time()
            state["showing_desktop"] = not state["showing_desktop"]
            if libX11 and dpy_ptr:
                toggle_x11_showing_desktop(libX11, dpy_ptr, root_xid, state["showing_desktop"])
        elif item.get("xids") and libX11 and dpy_ptr:
            # Find icon's exact root screen geometry for Linux shrink-to-dock-icon animation
            icon_geom = item.get("_last_icon_geom")
            if not icon_geom:
                icon_geom = (state["win_x"] + state["win_w"] // 2, state["win_y"] + state["win_h"] - 48, 48, 48)
            rx, ry, rw, rh = icon_geom

            visible_xids = [x for x in item["xids"] if x not in item.get("hidden_xids", [])]
            should_minimize = (
                cfg.get("click_to_minimize", True)
                and len(visible_xids) > 0
                and (item.get("focused", False) or item.get("_just_activated", False))
            )

            if should_minimize:
                target_xid = visible_xids[0]
                item["shrink_t"] = time.time()
                item["focused"] = False
                item["_just_activated"] = False
                minimize_x11_window_to_dock_icon(
                    libX11, dpy_ptr, root_xid, scr_num, target_xid, rx, ry, rw, rh
                )
            else:
                target_xid = item["xids"][0]
                item["bounce_t"] = time.time()
                item["focused"] = True
                item["_just_activated"] = True
                activate_x11_window(libX11, dpy_ptr, root_xid, target_xid, rx, ry, rw, rh)
        else:
            item["bounce_t"] = time.time()
            item["running"] = True
            item["_just_activated"] = True
            launch_command(item["exec"])

    def on_motion(_widget, event):
        state["pointer_x"] = float(event.x)
        state["pointer_y"] = float(event.y)
        state["last_leave_time"] = time.time()
        return False

    def on_leave(_widget, _event):
        state["pointer_x"] = None
        state["pointer_y"] = None
        state["last_leave_time"] = time.time()
        return False

    def on_button_press(_widget, event):
        bx, by = float(event.x), float(event.y)
        hit_item = None
        for rx, ry, rw, rh, item in state["item_rects"]:
            if rx <= bx <= rx + rw and ry <= by <= ry + rh:
                hit_item = item
                break

        if event.button == 1 and hit_item is not None:
            handle_item_activate(hit_item)
            return True
        elif event.button == 3:
            show_context_menu(event, hit_item)
            return True
        elif event.button == 2:
            cfg["position"] = "top" if cfg.get("position") == "bottom" else "bottom"
            save_runtime_config(cfg)
            reposition_dock_window()
            win.queue_draw()
            return True
        return False

    win.connect("draw", on_draw)
    win.connect("motion-notify-event", on_motion)
    win.connect("leave-notify-event", on_leave)
    win.connect("button-press-event", on_button_press)
    win.connect("destroy", Gtk.main_quit)

    sync_live_running_windows()
    reposition_dock_window()
    win.show_all()
    reposition_dock_window()

    if open_prefs_on_start:
        GLib.idle_add(open_preferences_window)

    GLib.timeout_add(16, tick_physics)
    GLib.timeout_add(400, sync_live_running_windows)

    wx, wy, ww, wh = get_monitor_workarea()
    loaded_icons = sum(1 for it in items if it.get("pixbuf") is not None)
    print(
        f"[Urdocks 3.0.0] GTK3/GdkX11 Liquid Glass Dock active on {display_name} "
        f"(workarea={ww}x{wh}+{wx}+{wy}, composited={is_composited}, "
        f"icons={loaded_icons}/{len(items)}, accent={state['sys_accent_label']})"
    )
    print(
        "[Urdocks 3.0.0] Author: Haris Gitama (https://github.com/Harisgitama) | "
        "Controls: Left-Click open app to minimize/shrink to dock | Right-Click for Pin & Presets"
    )

    try:
        Gtk.main()
    except KeyboardInterrupt:
        pass
    finally:
        if libX11 and dpy_ptr:
            libX11.XCloseDisplay(dpy_ptr)
    return True


# ============================================================================
# 6. FALLBACK ENGINE: PURE C-ABI X11 + XRENDER ARGB8888 + CAIRO + XSHAPE
# ============================================================================

TrueColor = 4
AllocNone = 0
InputOutput = 1

CWBackPixmap = 1 << 0
CWBackPixel = 1 << 1
CWBorderPixel = 1 << 3
CWOverrideRedirect = 1 << 9
CWEventMask = 1 << 11
CWColormap = 1 << 13

ExposureMask = 1 << 15
PointerMotionMask = 1 << 6
ButtonPressMask = 1 << 2
ButtonReleaseMask = 1 << 3
EnterWindowMask = 1 << 4
LeaveWindowMask = 1 << 5
StructureNotifyMask = 1 << 17
SubstructureNotifyMask = 1 << 19
SubstructureRedirectMask = 1 << 20

ButtonPress = 4
MotionNotify = 6
EnterNotify = 7
LeaveNotify = 8
Expose = 12
ConfigureNotify = 22
ClientMessage = 33

PropModeReplace = 0

ShapeSet = 0
ShapeBounding = 0
ShapeInput = 2
Unsorted = 0

CAIRO_FORMAT_ARGB32 = 0
CAIRO_OPERATOR_CLEAR = 0
CAIRO_OPERATOR_SOURCE = 1
CAIRO_OPERATOR_OVER = 2

VisualScreenMask = 0x2
VisualDepthMask = 0x4
VisualClassMask = 0x8
VisualRedMaskMask = 0x10
VisualGreenMaskMask = 0x20
VisualBlueMaskMask = 0x40


class XVisualInfo(ctypes.Structure):
    _fields_ = [
        ("visual", ctypes.c_void_p),
        ("visualid", ctypes.c_ulong),
        ("screen", ctypes.c_int),
        ("depth", ctypes.c_int),
        ("c_class", ctypes.c_int),
        ("red_mask", ctypes.c_ulong),
        ("green_mask", ctypes.c_ulong),
        ("blue_mask", ctypes.c_ulong),
        ("colormap_size", ctypes.c_int),
        ("bits_per_rgb", ctypes.c_int),
    ]


class XSetWindowAttributes(ctypes.Structure):
    _fields_ = [
        ("background_pixmap", ctypes.c_ulong),
        ("background_pixel", ctypes.c_ulong),
        ("border_pixmap", ctypes.c_ulong),
        ("border_pixel", ctypes.c_ulong),
        ("bit_gravity", ctypes.c_int),
        ("win_gravity", ctypes.c_int),
        ("backing_store", ctypes.c_int),
        ("backing_planes", ctypes.c_ulong),
        ("backing_pixel", ctypes.c_ulong),
        ("save_under", ctypes.c_int),
        ("event_mask", ctypes.c_long),
        ("do_not_propagate_mask", ctypes.c_long),
        ("override_redirect", ctypes.c_int),
        ("colormap", ctypes.c_ulong),
        ("cursor", ctypes.c_ulong),
    ]


class XRectangle(ctypes.Structure):
    _fields_ = [
        ("x", ctypes.c_short),
        ("y", ctypes.c_short),
        ("width", ctypes.c_ushort),
        ("height", ctypes.c_ushort),
    ]


class XErrorEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("resourceid", ctypes.c_ulong),
        ("serial", ctypes.c_ulong),
        ("error_code", ctypes.c_ubyte),
        ("request_code", ctypes.c_ubyte),
        ("minor_code", ctypes.c_ubyte),
    ]


class XAnyEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
    ]


class XMotionEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
        ("root", ctypes.c_ulong),
        ("subwindow", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("x", ctypes.c_int),
        ("y", ctypes.c_int),
        ("x_root", ctypes.c_int),
        ("y_root", ctypes.c_int),
        ("state", ctypes.c_uint),
        ("is_hint", ctypes.c_char),
        ("same_screen", ctypes.c_int),
    ]


class XButtonEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
        ("root", ctypes.c_ulong),
        ("subwindow", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("x", ctypes.c_int),
        ("y", ctypes.c_int),
        ("x_root", ctypes.c_int),
        ("y_root", ctypes.c_int),
        ("state", ctypes.c_uint),
        ("button", ctypes.c_uint),
        ("same_screen", ctypes.c_int),
    ]


class XClientMessageEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
        ("message_type", ctypes.c_ulong),
        ("format", ctypes.c_int),
        ("data", ctypes.c_long * 5),
    ]


class XEvent(ctypes.Union):
    _fields_ = [
        ("type", ctypes.c_int),
        ("xany", XAnyEvent),
        ("xmotion", XMotionEvent),
        ("xbutton", XButtonEvent),
        ("xclient", XClientMessageEvent),
        ("pad", ctypes.c_long * 24),
    ]


XErrorHandlerType = ctypes.CFUNCTYPE(
    ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(XErrorEvent)
)


@XErrorHandlerType
def _ignore_x11_error(_dpy, _err):
    return 0


def load_native_libraries():
    libX11 = ctypes.CDLL("libX11.so.6")
    libXext = ctypes.CDLL("libXext.so.6")
    libcairo = ctypes.CDLL("libcairo.so.2")
    libpixbuf = None
    libgobject = None
    try:
        libpixbuf = ctypes.CDLL("libgdk_pixbuf-2.0.so.0")
        libgobject = ctypes.CDLL("libgobject-2.0.so.0")
    except OSError:
        pass

    libX11.XSetErrorHandler.argtypes = [XErrorHandlerType]
    libX11.XSetErrorHandler.restype = ctypes.c_void_p
    libX11.XSetErrorHandler(_ignore_x11_error)

    libX11.XOpenDisplay.argtypes = [ctypes.c_char_p]
    libX11.XOpenDisplay.restype = ctypes.c_void_p

    libX11.XCloseDisplay.argtypes = [ctypes.c_void_p]
    libX11.XCloseDisplay.restype = ctypes.c_int

    libX11.XDefaultScreen.argtypes = [ctypes.c_void_p]
    libX11.XDefaultScreen.restype = ctypes.c_int

    libX11.XRootWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XRootWindow.restype = ctypes.c_ulong

    libX11.XDisplayWidth.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XDisplayWidth.restype = ctypes.c_int

    libX11.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XDisplayHeight.restype = ctypes.c_int

    libX11.XDefaultVisual.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XDefaultVisual.restype = ctypes.c_void_p

    libX11.XDefaultDepth.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XDefaultDepth.restype = ctypes.c_int

    libX11.XDefaultColormap.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libX11.XDefaultColormap.restype = ctypes.c_ulong

    libX11.XGetSelectionOwner.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    libX11.XGetSelectionOwner.restype = ctypes.c_ulong

    libX11.XGetVisualInfo.argtypes = [
        ctypes.c_void_p,
        ctypes.c_long,
        ctypes.POINTER(XVisualInfo),
        ctypes.POINTER(ctypes.c_int),
    ]
    libX11.XGetVisualInfo.restype = ctypes.POINTER(XVisualInfo)

    libX11.XCreateColormap.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_void_p,
        ctypes.c_int,
    ]
    libX11.XCreateColormap.restype = ctypes.c_ulong

    libX11.XCreateWindow.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_uint,
        ctypes.c_int,
        ctypes.c_uint,
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.POINTER(XSetWindowAttributes),
    ]
    libX11.XCreateWindow.restype = ctypes.c_ulong

    libX11.XMoveResizeWindow.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_uint,
        ctypes.c_uint,
    ]
    libX11.XMoveResizeWindow.restype = ctypes.c_int

    libX11.XStoreName.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_char_p]
    libX11.XStoreName.restype = ctypes.c_int

    libX11.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    libX11.XInternAtom.restype = ctypes.c_ulong

    libX11.XChangeProperty.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_ulong,
        ctypes.c_ulong,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_void_p,
        ctypes.c_int,
    ]
    libX11.XChangeProperty.restype = ctypes.c_int

    libX11.XGetWindowProperty.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_ulong,
        ctypes.c_long,
        ctypes.c_long,
        ctypes.c_int,
        ctypes.c_ulong,
        ctypes.POINTER(ctypes.c_ulong),
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_ulong),
        ctypes.POINTER(ctypes.c_ulong),
        ctypes.POINTER(ctypes.POINTER(ctypes.c_ulong)),
    ]
    libX11.XGetWindowProperty.restype = ctypes.c_int

    libX11.XFree.argtypes = [ctypes.c_void_p]
    libX11.XFree.restype = ctypes.c_int

    libX11.XMapRaised.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    libX11.XMapRaised.restype = ctypes.c_int

    libX11.XRaiseWindow.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    libX11.XRaiseWindow.restype = ctypes.c_int

    try:
        libX11.XIconifyWindow.argtypes = [
            ctypes.c_void_p,
            ctypes.c_ulong,
            ctypes.c_int,
        ]
        libX11.XIconifyWindow.restype = ctypes.c_int
    except Exception:
        pass

    libX11.XSendEvent.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_int,
        ctypes.c_long,
        ctypes.POINTER(XEvent),
    ]
    libX11.XSendEvent.restype = ctypes.c_int

    libX11.XFlush.argtypes = [ctypes.c_void_p]
    libX11.XFlush.restype = ctypes.c_int

    libX11.XPending.argtypes = [ctypes.c_void_p]
    libX11.XPending.restype = ctypes.c_int

    libX11.XNextEvent.argtypes = [ctypes.c_void_p, ctypes.POINTER(XEvent)]
    libX11.XNextEvent.restype = ctypes.c_int

    libXext.XShapeCombineRectangles.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.POINTER(XRectangle),
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
    ]
    libXext.XShapeCombineRectangles.restype = None

    libcairo.cairo_xlib_surface_create.argtypes = [
        ctypes.c_void_p,
        ctypes.c_ulong,
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_int,
    ]
    libcairo.cairo_xlib_surface_create.restype = ctypes.c_void_p

    libcairo.cairo_image_surface_create.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
    ]
    libcairo.cairo_image_surface_create.restype = ctypes.c_void_p

    libcairo.cairo_image_surface_create_for_data.argtypes = [
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
    ]
    libcairo.cairo_image_surface_create_for_data.restype = ctypes.c_void_p

    libcairo.cairo_create.argtypes = [ctypes.c_void_p]
    libcairo.cairo_create.restype = ctypes.c_void_p

    libcairo.cairo_destroy.argtypes = [ctypes.c_void_p]
    libcairo.cairo_destroy.restype = None

    libcairo.cairo_surface_destroy.argtypes = [ctypes.c_void_p]
    libcairo.cairo_surface_destroy.restype = None

    libcairo.cairo_surface_flush.argtypes = [ctypes.c_void_p]
    libcairo.cairo_surface_flush.restype = None

    libcairo.cairo_push_group.argtypes = [ctypes.c_void_p]
    libcairo.cairo_push_group.restype = None

    libcairo.cairo_pop_group_to_source.argtypes = [ctypes.c_void_p]
    libcairo.cairo_pop_group_to_source.restype = None

    libcairo.cairo_save.argtypes = [ctypes.c_void_p]
    libcairo.cairo_save.restype = None

    libcairo.cairo_restore.argtypes = [ctypes.c_void_p]
    libcairo.cairo_restore.restype = None

    libcairo.cairo_set_operator.argtypes = [ctypes.c_void_p, ctypes.c_int]
    libcairo.cairo_set_operator.restype = None

    libcairo.cairo_set_source_rgba.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_set_source_rgba.restype = None

    libcairo.cairo_set_source_surface.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_set_source_surface.restype = None

    libcairo.cairo_translate.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_translate.restype = None

    libcairo.cairo_scale.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_scale.restype = None

    libcairo.cairo_paint.argtypes = [ctypes.c_void_p]
    libcairo.cairo_paint.restype = None

    libcairo.cairo_new_path.argtypes = [ctypes.c_void_p]
    libcairo.cairo_new_path.restype = None

    libcairo.cairo_new_sub_path.argtypes = [ctypes.c_void_p]
    libcairo.cairo_new_sub_path.restype = None

    libcairo.cairo_close_path.argtypes = [ctypes.c_void_p]
    libcairo.cairo_close_path.restype = None

    libcairo.cairo_arc.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_arc.restype = None

    libcairo.cairo_move_to.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_move_to.restype = None

    libcairo.cairo_line_to.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_line_to.restype = None

    libcairo.cairo_curve_to.argtypes = [
        ctypes.c_void_p,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
    ]
    libcairo.cairo_curve_to.restype = None

    libcairo.cairo_set_line_width.argtypes = [ctypes.c_void_p, ctypes.c_double]
    libcairo.cairo_set_line_width.restype = None

    libcairo.cairo_fill.argtypes = [ctypes.c_void_p]
    libcairo.cairo_fill.restype = None

    libcairo.cairo_fill_preserve.argtypes = [ctypes.c_void_p]
    libcairo.cairo_fill_preserve.restype = None

    libcairo.cairo_stroke.argtypes = [ctypes.c_void_p]
    libcairo.cairo_stroke.restype = None

    libcairo.cairo_select_font_face.argtypes = [
        ctypes.c_void_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_int,
    ]
    libcairo.cairo_select_font_face.restype = None

    libcairo.cairo_set_font_size.argtypes = [ctypes.c_void_p, ctypes.c_double]
    libcairo.cairo_set_font_size.restype = None

    libcairo.cairo_show_text.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    libcairo.cairo_show_text.restype = None

    if libpixbuf:
        libpixbuf.gdk_pixbuf_new_from_file_at_scale.argtypes = [
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_void_p,
        ]
        libpixbuf.gdk_pixbuf_new_from_file_at_scale.restype = ctypes.c_void_p
        libpixbuf.gdk_pixbuf_get_width.argtypes = [ctypes.c_void_p]
        libpixbuf.gdk_pixbuf_get_width.restype = ctypes.c_int
        libpixbuf.gdk_pixbuf_get_height.argtypes = [ctypes.c_void_p]
        libpixbuf.gdk_pixbuf_get_height.restype = ctypes.c_int
        libpixbuf.gdk_pixbuf_get_rowstride.argtypes = [ctypes.c_void_p]
        libpixbuf.gdk_pixbuf_get_rowstride.restype = ctypes.c_int
        libpixbuf.gdk_pixbuf_get_n_channels.argtypes = [ctypes.c_void_p]
        libpixbuf.gdk_pixbuf_get_n_channels.restype = ctypes.c_int
        libpixbuf.gdk_pixbuf_get_pixels.argtypes = [ctypes.c_void_p]
        libpixbuf.gdk_pixbuf_get_pixels.restype = ctypes.c_void_p

    if libgobject:
        libgobject.g_object_unref.argtypes = [ctypes.c_void_p]
        libgobject.g_object_unref.restype = None

    return libX11, libXext, libcairo, libpixbuf, libgobject


def find_true_argb8888_visual(libX11, dpy, screen):
    cm_atom_name = f"_NET_WM_CM_S{screen}".encode("utf-8")
    cm_atom = libX11.XInternAtom(dpy, cm_atom_name, 0)
    if libX11.XGetSelectionOwner(dpy, cm_atom) == 0:
        return None

    tmpl = XVisualInfo()
    tmpl.screen = screen
    tmpl.depth = 32
    tmpl.c_class = TrueColor
    tmpl.red_mask = 0xFF0000
    tmpl.green_mask = 0x00FF00
    tmpl.blue_mask = 0x0000FF
    mask = (
        VisualScreenMask
        | VisualDepthMask
        | VisualClassMask
        | VisualRedMaskMask
        | VisualGreenMaskMask
        | VisualBlueMaskMask
    )
    nitems = ctypes.c_int(0)
    vinfo_ptr = libX11.XGetVisualInfo(dpy, mask, ctypes.byref(tmpl), ctypes.byref(nitems))
    if vinfo_ptr and nitems.value > 0:
        vis = vinfo_ptr[0].visual
        libX11.XFree(vinfo_ptr)
        return vis
    if vinfo_ptr:
        libX11.XFree(vinfo_ptr)
    return None


def draw_rounded_rect(libcairo, cr, x, y, w, h, r):
    r = min(r, w * 0.5, h * 0.5)
    libcairo.cairo_new_sub_path(cr)
    libcairo.cairo_arc(cr, x + w - r, y + r, r, -math.pi * 0.5, 0.0)
    libcairo.cairo_arc(cr, x + w - r, y + h - r, r, 0.0, math.pi * 0.5)
    libcairo.cairo_arc(cr, x + r, y + h - r, r, math.pi * 0.5, math.pi)
    libcairo.cairo_arc(cr, x + r, y + r, r, math.pi, 1.5 * math.pi)
    libcairo.cairo_close_path(cr)


def draw_apple_superellipse_capsule_cabi(libcairo, cr, x, y, w, h):
    """
    Apple Continuous-Curvature Superellipse (Squircle) Capsule for C-ABI Cairo fallback.
    """
    ry = h * 0.5
    rx = min(w * 0.5, h * 0.64)
    k = 0.635
    libcairo.cairo_new_sub_path(cr)
    libcairo.cairo_move_to(cr, x + rx, y)
    libcairo.cairo_line_to(cr, x + w - rx, y)
    libcairo.cairo_curve_to(
        cr,
        x + w - rx * (1.0 - k),
        y,
        x + w,
        y + ry * (1.0 - k),
        x + w,
        y + ry,
    )
    libcairo.cairo_curve_to(
        cr,
        x + w,
        y + h - ry * (1.0 - k),
        x + w - rx * (1.0 - k),
        y + h,
        x + w - rx,
        y + h,
    )
    libcairo.cairo_line_to(cr, x + rx, y + h)
    libcairo.cairo_curve_to(
        cr,
        x + rx * (1.0 - k),
        y + h,
        x,
        y + h - ry * (1.0 - k),
        x,
        y + ry,
    )
    libcairo.cairo_curve_to(
        cr,
        x,
        y + ry * (1.0 - k),
        x + rx * (1.0 - k),
        y,
        x + rx,
        y,
    )
    libcairo.cairo_close_path(cr)


def draw_vector_glyph(libcairo, cr, kind, ix, iy, sz):
    cx = ix + sz * 0.5
    cy = iy + sz * 0.5
    libcairo.cairo_set_line_width(cr, max(1.8, sz * 0.055))
    libcairo.cairo_set_source_rgba(cr, 1.0, 1.0, 1.0, 0.95)

    if kind == "launcher":
        g = sz * 0.16
        gap = sz * 0.06
        for r in (-1, 1):
            for c in (-1, 1):
                draw_rounded_rect(
                    libcairo,
                    cr,
                    cx + c * (g * 0.5 + gap) - g * 0.5,
                    cy + r * (g * 0.5 + gap) - g * 0.5,
                    g,
                    g,
                    g * 0.28,
                )
                libcairo.cairo_fill(cr)
    elif kind == "files":
        fw = sz * 0.48
        fh = sz * 0.38
        fx = cx - fw * 0.5
        fy = cy - fh * 0.42
        draw_rounded_rect(libcairo, cr, fx, fy, fw, fh, sz * 0.06)
        libcairo.cairo_stroke(cr)
        libcairo.cairo_move_to(cr, fx, fy + fh * 0.28)
        libcairo.cairo_line_to(cr, fx + fw, fy + fh * 0.28)
        libcairo.cairo_stroke(cr)
    elif kind == "browser":
        rad = sz * 0.26
        libcairo.cairo_new_path(cr)
        libcairo.cairo_arc(cr, cx, cy, rad, 0.0, 2.0 * math.pi)
        libcairo.cairo_stroke(cr)
        libcairo.cairo_move_to(cr, cx - rad, cy)
        libcairo.cairo_line_to(cr, cx + rad, cy)
        libcairo.cairo_move_to(cr, cx, cy - rad)
        libcairo.cairo_line_to(cr, cx, cy + rad)
        libcairo.cairo_stroke(cr)
    elif kind == "terminal":
        libcairo.cairo_move_to(cr, cx - sz * 0.20, cy - sz * 0.12)
        libcairo.cairo_line_to(cr, cx - sz * 0.04, cy)
        libcairo.cairo_line_to(cr, cx - sz * 0.20, cy + sz * 0.12)
        libcairo.cairo_move_to(cr, cx + sz * 0.02, cy + sz * 0.14)
        libcairo.cairo_line_to(cr, cx + sz * 0.20, cy + sz * 0.14)
        libcairo.cairo_stroke(cr)
    elif kind == "code":
        libcairo.cairo_move_to(cr, cx - sz * 0.10, cy - sz * 0.14)
        libcairo.cairo_line_to(cr, cx - sz * 0.22, cy)
        libcairo.cairo_line_to(cr, cx - sz * 0.10, cy + sz * 0.14)
        libcairo.cairo_move_to(cr, cx + sz * 0.10, cy - sz * 0.14)
        libcairo.cairo_line_to(cr, cx + sz * 0.22, cy)
        libcairo.cairo_line_to(cr, cx + sz * 0.10, cy + sz * 0.14)
        libcairo.cairo_stroke(cr)
    else:
        dw = sz * 0.38
        dh = sz * 0.42
        draw_rounded_rect(libcairo, cr, cx - dw * 0.5, cy - dh * 0.5, dw, dh, 4.0)
        libcairo.cairo_stroke(cr)


def load_icon_cairo_surface(libcairo, libpixbuf, libgobject, icon_path, target_px=96):
    if not libpixbuf or not icon_path or not os.path.isfile(icon_path):
        return None, None, 0, 0

    pb = libpixbuf.gdk_pixbuf_new_from_file_at_scale(
        icon_path.encode("utf-8"), target_px, target_px, 1, None
    )
    if not pb:
        return None, None, 0, 0

    w = libpixbuf.gdk_pixbuf_get_width(pb)
    h = libpixbuf.gdk_pixbuf_get_height(pb)
    stride = libpixbuf.gdk_pixbuf_get_rowstride(pb)
    ch = libpixbuf.gdk_pixbuf_get_n_channels(pb)
    pixels_ptr = libpixbuf.gdk_pixbuf_get_pixels(pb)

    raw_len = stride * h
    raw = ctypes.string_at(pixels_ptr, raw_len)
    if libgobject:
        libgobject.g_object_unref(pb)

    buf = ctypes.create_string_buffer(w * h * 4)
    out = memoryview(buf).cast("B")
    src = memoryview(raw)

    for y in range(h):
        row_off = y * stride
        dst_off = y * w * 4
        for x in range(w):
            p = row_off + x * ch
            r = src[p]
            g = src[p + 1]
            b = src[p + 2]
            a = src[p + 3] if ch >= 4 else 255
            if a == 0:
                out[dst_off : dst_off + 4] = b"\x00\x00\x00\x00"
            elif a == 255:
                out[dst_off] = b
                out[dst_off + 1] = g
                out[dst_off + 2] = r
                out[dst_off + 3] = 255
            else:
                out[dst_off] = (b * a + 127) // 255
                out[dst_off + 1] = (g * a + 127) // 255
                out[dst_off + 2] = (r * a + 127) // 255
                out[dst_off + 3] = a
            dst_off += 4

    surf = libcairo.cairo_image_surface_create_for_data(
        buf, CAIRO_FORMAT_ARGB32, w, h, w * 4
    )
    return surf, buf, w, h


def build_dock_items_for_xlib(libcairo=None, libpixbuf=None, libgobject=None):
    items = build_dock_items_catalog()
    for it in items:
        ipath = it.get("icon_path")
        if libcairo and libpixbuf and ipath:
            surf, buf, iw, ih = load_icon_cairo_surface(
                libcairo, libpixbuf, libgobject, ipath, 96
            )
            it["cairo_surf"] = surf
            it["cairo_buf"] = buf
            it["surf_w"] = iw
            it["surf_h"] = ih
        else:
            it["cairo_surf"] = None
    return items


def render_dock_to_cairo_context(
    libcairo, cr, win_w, win_h, items, pointer_x, has_argb, theme_idx=0, accent_rgb=(0.18, 0.70, 0.60)
):
    libcairo.cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR if has_argb else CAIRO_OPERATOR_OVER)
    if has_argb:
        libcairo.cairo_set_source_rgba(cr, 0.0, 0.0, 0.0, 0.0)
    else:
        libcairo.cairo_set_source_rgba(cr, 0.08, 0.10, 0.15, 1.0)
    libcairo.cairo_paint(cr)
    libcairo.cairo_set_operator(cr, CAIRO_OPERATOR_OVER)

    base_size = 48.0
    spacing = 10.0
    max_scale = 1.56
    range_px = base_size * 3.0
    shelf_pad_x = 14.0
    shelf_pad_y = 8.0
    bottom_margin = 8.0

    scales = []
    temp_x = 0.0
    centers = []
    for _ in items:
        c = temp_x + base_size * 0.5
        centers.append(c)
        temp_x += base_size + spacing

    unscaled_w = len(items) * base_size + (len(items) - 1) * spacing
    track_start_unscaled = (win_w - unscaled_w) * 0.5
    rel_px = (pointer_x - track_start_unscaled) if pointer_x is not None else None

    for c in centers:
        if rel_px is not None:
            dist = abs(rel_px - c)
            if dist < range_px:
                w = 0.5 * (1.0 + math.cos(math.pi * dist / range_px))
                scales.append(1.0 + (max_scale - 1.0) * w)
            else:
                scales.append(1.0)
        else:
            scales.append(1.0)

    sizes = [base_size * s for s in scales]
    total_icons_w = sum(sizes) + spacing * (len(items) - 1)
    shelf_w = total_icons_w + shelf_pad_x * 2.0
    shelf_h = base_size + shelf_pad_y * 2.0
    shelf_x = (win_w - shelf_w) * 0.5
    shelf_y = win_h - bottom_margin - shelf_h

    _, bg_rgba, _ = THEMES[theme_idx % len(THEMES)]

    draw_rounded_rect(libcairo, cr, shelf_x, shelf_y, shelf_w, shelf_h, 18.0)
    libcairo.cairo_set_source_rgba(cr, bg_rgba[0], bg_rgba[1], bg_rgba[2], bg_rgba[3])
    libcairo.cairo_fill_preserve(cr)
    libcairo.cairo_set_line_width(cr, 1.0)
    libcairo.cairo_set_source_rgba(cr, 0.0, 0.0, 0.0, 0.52)
    libcairo.cairo_stroke(cr)

    draw_rounded_rect(
        libcairo,
        cr,
        shelf_x + 1.0,
        shelf_y + 1.0,
        shelf_w - 2.0,
        shelf_h - 2.0,
        17.0,
    )
    libcairo.cairo_set_source_rgba(
        cr, accent_rgb[0], accent_rgb[1], accent_rgb[2], 0.42
    )
    libcairo.cairo_stroke(cr)

    cur_x = shelf_x + shelf_pad_x
    hovered_idx = None
    if pointer_x is not None:
        best_s = 1.02
        for idx, s in enumerate(scales):
            if s > best_s:
                best_s = s
                hovered_idx = idx

    item_rects = []
    for idx, item in enumerate(items):
        sz = sizes[idx]
        ix = cur_x
        iy = (shelf_y + shelf_h - shelf_pad_y) - sz
        item_rects.append((ix, iy, sz, sz, item))

        r, g, b = item["rgb"]
        draw_rounded_rect(libcairo, cr, ix, iy, sz, sz, sz * 0.24)
        libcairo.cairo_set_source_rgba(cr, r, g, b, 0.94)
        libcairo.cairo_fill_preserve(cr)
        libcairo.cairo_set_line_width(cr, 1.0)
        libcairo.cairo_set_source_rgba(cr, 1.0, 1.0, 1.0, 0.36)
        libcairo.cairo_stroke(cr)

        if item.get("cairo_surf") and item.get("surf_w", 0) > 0:
            pad = sz * 0.10
            target_dim = sz - pad * 2.0
            sx = target_dim / float(item["surf_w"])
            sy = target_dim / float(item["surf_h"])
            libcairo.cairo_save(cr)
            libcairo.cairo_translate(cr, ix + pad, iy + pad)
            libcairo.cairo_scale(cr, sx, sy)
            libcairo.cairo_set_source_surface(cr, item["cairo_surf"], 0.0, 0.0)
            libcairo.cairo_paint(cr)
            libcairo.cairo_restore(cr)
        else:
            draw_vector_glyph(libcairo, cr, item.get("glyph", "doc"), ix, iy, sz)

        if item.get("running", False):
            dot_x = ix + sz * 0.5
            dot_y = shelf_y + shelf_h - 3.5
            libcairo.cairo_new_path(cr)
            libcairo.cairo_arc(cr, dot_x, dot_y, 2.4, 0.0, 2.0 * math.pi)
            libcairo.cairo_set_source_rgba(cr, accent_rgb[0], accent_rgb[1], accent_rgb[2], 0.98)
            libcairo.cairo_fill(cr)

        if hovered_idx == idx:
            label_bytes = item["name"].encode("utf-8")
            tw = max(84.0, len(item["name"]) * 7.2 + 28.0)
            th = 26.0
            tx = max(4.0, min(win_w - tw - 4.0, ix + sz * 0.5 - tw * 0.5))
            ty = max(2.0, iy - th - 10.0)
            draw_apple_superellipse_capsule_cabi(libcairo, cr, tx, ty, tw, th)
            libcairo.cairo_set_source_rgba(cr, 0.07, 0.09, 0.14, 0.90)
            libcairo.cairo_fill_preserve(cr)
            libcairo.cairo_set_source_rgba(cr, accent_rgb[0], accent_rgb[1], accent_rgb[2], 0.65)
            libcairo.cairo_stroke(cr)

            libcairo.cairo_select_font_face(cr, b"Sans", 0, 1)
            libcairo.cairo_set_font_size(cr, 12.0)
            libcairo.cairo_set_source_rgba(cr, 0.96, 0.98, 1.0, 1.0)
            libcairo.cairo_move_to(cr, tx + 13.0, ty + 17.0)
            libcairo.cairo_show_text(cr, label_bytes)

        cur_x += sz + spacing

    return (shelf_x, shelf_y, shelf_w, shelf_h), item_rects


def query_bottom_panel_inset(libX11, dpy, root, sh):
    atom_wa = libX11.XInternAtom(dpy, b"_NET_WORKAREA", 1)
    if not atom_wa:
        return 0
    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop_ptr = ctypes.POINTER(ctypes.c_ulong)()
    res = libX11.XGetWindowProperty(
        dpy,
        root,
        atom_wa,
        0,
        4,
        0,
        XA_CARDINAL,
        ctypes.byref(actual_type),
        ctypes.byref(actual_format),
        ctypes.byref(nitems),
        ctypes.byref(bytes_after),
        ctypes.byref(prop_ptr),
    )
    inset = 0
    if res == 0 and prop_ptr and nitems.value >= 4:
        work_y = prop_ptr[1]
        work_h = prop_ptr[3]
        bottom_gap = sh - (work_y + work_h)
        if 16 <= bottom_gap <= 96:
            inset = int(bottom_gap)
    if prop_ptr:
        libX11.XFree(prop_ptr)
    return inset


def toggle_x11_showing_desktop(libX11, dpy, root, state_flag):
    atom_sd = libX11.XInternAtom(dpy, b"_NET_SHOWING_DESKTOP", 0)
    ev = XEvent()
    ev.xclient.type = ClientMessage
    ev.xclient.window = root
    ev.xclient.message_type = atom_sd
    ev.xclient.format = 32
    ev.xclient.data[0] = 1 if state_flag else 0
    ev.xclient.data[1] = 0
    ev.xclient.data[2] = 0
    ev.xclient.data[3] = 0
    ev.xclient.data[4] = 0
    libX11.XSendEvent(
        dpy,
        root,
        0,
        SubstructureRedirectMask | SubstructureNotifyMask,
        ctypes.byref(ev),
    )
    libX11.XFlush(dpy)


def run_xlib_visual_dock():
    display_name = ensure_x11_environment()
    libX11, libXext, libcairo, libpixbuf, libgobject = load_native_libraries()
    accent_rgb, _ = detect_linux_system_accent_color()

    if not display_name:
        print(
            "[rust-plank 2.1.0] Notice: No X11 socket found in /tmp/.X11-unix and $DISPLAY is not set.",
            file=sys.stderr,
        )
        return 0

    dpy = libX11.XOpenDisplay(display_name.encode("utf-8"))
    if not dpy:
        dpy = libX11.XOpenDisplay(None)
    if not dpy:
        print(
            f"[rust-plank 2.1.0] Error: Cannot connect to X11 display {display_name} (check XAUTHORITY)",
            file=sys.stderr,
        )
        return 1

    screen = libX11.XDefaultScreen(dpy)
    root = libX11.XRootWindow(dpy, screen)
    sw = libX11.XDisplayWidth(dpy, screen)
    sh = libX11.XDisplayHeight(dpy, screen)

    panel_inset = query_bottom_panel_inset(libX11, dpy, root, sh)
    win_w = min(sw, 980)
    win_h = 165
    win_x = (sw - win_w) // 2
    win_y = sh - win_h - panel_inset

    argb_visual = find_true_argb8888_visual(libX11, dpy, screen)
    has_argb = argb_visual is not None
    if has_argb:
        visual = argb_visual
        depth = 32
        colormap = libX11.XCreateColormap(dpy, root, visual, AllocNone)
    else:
        visual = libX11.XDefaultVisual(dpy, screen)
        depth = libX11.XDefaultDepth(dpy, screen)
        colormap = libX11.XDefaultColormap(dpy, screen)

    attrs = XSetWindowAttributes()
    attrs.background_pixmap = 0
    attrs.background_pixel = 0
    attrs.border_pixel = 0
    attrs.override_redirect = 1
    attrs.colormap = colormap
    attrs.event_mask = (
        ExposureMask
        | PointerMotionMask
        | ButtonPressMask
        | ButtonReleaseMask
        | EnterWindowMask
        | LeaveWindowMask
        | StructureNotifyMask
    )

    value_mask = (
        CWBackPixmap
        | CWBackPixel
        | CWBorderPixel
        | CWOverrideRedirect
        | CWColormap
        | CWEventMask
    )
    win = libX11.XCreateWindow(
        dpy,
        root,
        win_x,
        win_y,
        win_w,
        win_h,
        0,
        depth,
        InputOutput,
        visual,
        value_mask,
        ctypes.byref(attrs),
    )

    libX11.XStoreName(dpy, win, b"rust-plank")

    atom_wt = libX11.XInternAtom(dpy, b"_NET_WM_WINDOW_TYPE", 0)
    atom_dock = libX11.XInternAtom(dpy, b"_NET_WM_WINDOW_TYPE_DOCK", 0)
    wt_val = ctypes.c_ulong(atom_dock)
    libX11.XChangeProperty(
        dpy, win, atom_wt, XA_ATOM, 32, PropModeReplace, ctypes.byref(wt_val), 1
    )

    atom_state = libX11.XInternAtom(dpy, b"_NET_WM_STATE", 0)
    StateArray = ctypes.c_ulong * 4
    states = StateArray(
        libX11.XInternAtom(dpy, b"_NET_WM_STATE_ABOVE", 0),
        libX11.XInternAtom(dpy, b"_NET_WM_STATE_STICKY", 0),
        libX11.XInternAtom(dpy, b"_NET_WM_STATE_SKIP_TASKBAR", 0),
        libX11.XInternAtom(dpy, b"_NET_WM_STATE_SKIP_PAGER", 0),
    )
    libX11.XChangeProperty(
        dpy, win, atom_state, XA_ATOM, 32, PropModeReplace, ctypes.byref(states), 4
    )

    libX11.XMapRaised(dpy, win)
    libX11.XMoveResizeWindow(dpy, win, win_x, win_y, win_w, win_h)
    libX11.XRaiseWindow(dpy, win)
    libX11.XFlush(dpy)

    xlib_surf = libcairo.cairo_xlib_surface_create(dpy, win, visual, win_w, win_h)
    xlib_cr = libcairo.cairo_create(xlib_surf)

    items = build_dock_items_for_xlib(libcairo, libpixbuf, libgobject)

    pointer_x = None
    theme_idx = 0
    pos_mode = 0
    showing_desktop = False

    def redraw():
        libcairo.cairo_push_group(xlib_cr)
        shelf_box, item_rects = render_dock_to_cairo_context(
            libcairo, xlib_cr, win_w, win_h, items, pointer_x, has_argb, theme_idx, accent_rgb
        )
        libcairo.cairo_pop_group_to_source(xlib_cr)
        libcairo.cairo_set_operator(xlib_cr, CAIRO_OPERATOR_SOURCE)
        libcairo.cairo_paint(xlib_cr)
        libcairo.cairo_surface_flush(xlib_surf)

        RectArray = XRectangle * (1 + len(item_rects))
        xrects = RectArray()
        xrects[0].x = int(shelf_box[0])
        xrects[0].y = int(shelf_box[1])
        xrects[0].width = max(1, int(shelf_box[2]))
        xrects[0].height = max(1, int(shelf_box[3]))
        for i, (rx, ry, rw, rh, _) in enumerate(item_rects):
            xrects[i + 1].x = int(rx)
            xrects[i + 1].y = int(ry)
            xrects[i + 1].width = max(1, int(rw))
            xrects[i + 1].height = max(1, int(rh))

        if has_argb:
            libXext.XShapeCombineRectangles(
                dpy, win, ShapeInput, 0, 0, xrects, len(xrects), ShapeSet, Unsorted
            )
        else:
            libXext.XShapeCombineRectangles(
                dpy, win, ShapeBounding, 0, 0, xrects, len(xrects), ShapeSet, Unsorted
            )
        libX11.XFlush(dpy)
        return item_rects

    current_rects = redraw()
    icons_loaded = sum(1 for it in items if it.get("cairo_surf"))
    print(
        f"[rust-plank 2.1.0] Xlib/Cairo Visual Dock mapped on {display_name} "
        f"({win_w}x{win_h} at x={win_x}, y={win_y}, panel_inset={panel_inset}px, "
        f"ARGB8888={has_argb}, system_icons={icons_loaded}/{len(items)})"
    )

    ev = XEvent()
    last_heartbeat = time.time()
    try:
        while True:
            needs_redraw = False
            while libX11.XPending(dpy) > 0:
                libX11.XNextEvent(dpy, ctypes.byref(ev))
                if ev.type == Expose or ev.type == ConfigureNotify:
                    needs_redraw = True
                elif ev.type == MotionNotify:
                    pointer_x = float(ev.xmotion.x)
                    needs_redraw = True
                elif ev.type == LeaveNotify:
                    pointer_x = None
                    needs_redraw = True
                elif ev.type == ButtonPress:
                    btn = ev.xbutton.button
                    bx, by = float(ev.xbutton.x), float(ev.xbutton.y)
                    if btn == 1:
                        for rx, ry, rw, rh, item in current_rects:
                            if rx <= bx <= rx + rw and ry <= by <= ry + rh:
                                if item["exec"] == "__toggle_desktop__":
                                    showing_desktop = not showing_desktop
                                    toggle_x11_showing_desktop(
                                        libX11, dpy, root, showing_desktop
                                    )
                                elif item["exec"] == "__open_preferences__":
                                    theme_idx = (theme_idx + 1) % len(THEMES)
                                    needs_redraw = True
                                else:
                                    launch_command(item["exec"])
                                break
                    elif btn == 3:
                        theme_idx = (theme_idx + 1) % len(THEMES)
                        needs_redraw = True
                    elif btn == 2:
                        pos_mode = 1 - pos_mode
                        new_y = 32 if pos_mode == 1 else (sh - win_h - panel_inset)
                        libX11.XMoveResizeWindow(dpy, win, win_x, new_y, win_w, win_h)
                        libX11.XRaiseWindow(dpy, win)
                        needs_redraw = True

            now = time.time()
            if now - last_heartbeat > 0.35:
                libX11.XRaiseWindow(dpy, win)
                needs_redraw = True
                last_heartbeat = now

            if needs_redraw:
                current_rects = redraw()
            time.sleep(0.016)
    except KeyboardInterrupt:
        pass
    finally:
        libcairo.cairo_destroy(xlib_cr)
        libcairo.cairo_surface_destroy(xlib_surf)
        libX11.XCloseDisplay(dpy)
    return 0


# ============================================================================
# 7. DIAGNOSTICS & CLI ENTRYPOINT
# ============================================================================

def run_diagnostics():
    display = ensure_x11_environment()
    print("Urdocks 3.0.0 (rust-plank) — X11 System & Visual Dock Diagnostics")
    print("=================================================================")
    print("[OK] Author & Repository:       Haris Gitama (https://github.com/Harisgitama)")
    libX11, libXext, libcairo, libpixbuf, libgobject = load_native_libraries()
    print(f"[OK] libX11.so.6 loaded:        {libX11._name} (XIconifyWindow + _NET_WM_ICON_GEOMETRY)")
    print(f"[OK] libXext.so.6 loaded:       {libXext._name} (XShapeCombineRectangles)")
    print(f"[OK] libcairo.so.2 loaded:      {libcairo._name} (Superellipse Squircle Capsule + Liquid Glass)")
    print(f"[OK] libgdk_pixbuf-2.0 loaded:  {bool(libpixbuf)}")

    gtk_avail = False
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk
        gtk_avail = True
    except Exception:
        pass
    print(f"[OK] GTK3/GdkX11 Engine:        {'Available (Primary Engine)' if gtk_avail else 'Fallback to Xlib/Cairo C-ABI'}")

    entries = scan_desktop_entries()
    print(f"[OK] XDG .desktop files parsed: {len(entries)} entries")

    presets = discover_icon_and_plasma_presets()
    plasma_cnt = sum(1 for p in presets if p[3] == "plasma")
    icon_cnt = len(glob.glob("/usr/share/icons/*"))
    print(f"[OK] /usr/share/icons themes:   {icon_cnt} icon themes + {plasma_cnt} Plasma desktopthemes")

    _, accent_label = detect_linux_system_accent_color()
    print(f"[OK] Active Linux Accent Sync:  {accent_label}")
    print("[OK] Theme Preset Default:      Liquid Glass (Clear Glass + Frosted Glass Slider)")
    print("[OK] Tooltip Geometry:          Apple Superellipse (Squircle Continuous Curve Capsule)")
    print("[OK] Click Open App Behavior:   Minimize & Native Shrink to Dock Icon (_NET_WM_ICON_GEOMETRY)")

    items = build_dock_items_for_xlib(libcairo, libpixbuf, libgobject)
    surf = libcairo.cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 980, 165)
    cr = libcairo.cairo_create(surf)
    shelf_box, rects = render_dock_to_cairo_context(
        libcairo, cr, 980, 165, items, 490.0, True, 0
    )
    libcairo.cairo_surface_flush(surf)
    libcairo.cairo_destroy(cr)
    libcairo.cairo_surface_destroy(surf)
    print(
        f"[OK] Cairo ARGB32 Dock Frame:   Rendered {len(rects)} icons on shelf ({int(shelf_box[2])}x{int(shelf_box[3])} px)"
    )
    print(f"[INFO] Active $DISPLAY:         {display or '(headless environment)'}")
    print(f"[INFO] Active $XAUTHORITY:      {os.environ.get('XAUTHORITY', '(default)')}")
    if display:
        dpy = libX11.XOpenDisplay(display.encode("utf-8")) or libX11.XOpenDisplay(None)
        if dpy:
            scr = libX11.XDefaultScreen(dpy)
            rt = libX11.XRootWindow(dpy, scr)
            sw = libX11.XDisplayWidth(dpy, scr)
            sh = libX11.XDisplayHeight(dpy, scr)
            argb_vis = find_true_argb8888_visual(libX11, dpy, scr)
            _, live_wins = query_live_x11_running_windows(libX11, dpy, rt)
            print(f"[OK] XOpenDisplay({display}):        Connected (Screen {scr}: {sw}x{sh}, ARGB8888={bool(argb_vis)}, RunningWindows={len(live_wins)})")
            libX11.XCloseDisplay(dpy)
    return 0


def main():
    if "--changelog" in sys.argv:
        print(CHANGELOG_TEXT)
        sys.exit(0)
    if "--diagnose" in sys.argv:
        sys.exit(run_diagnostics())

    open_prefs = ("--preferences" in sys.argv) or ("-p" in sys.argv)
    force_xlib = ("--engine=xlib" in sys.argv)

    if not force_xlib:
        if try_run_gtk_visual_dock(open_prefs_on_start=open_prefs):
            sys.exit(0)

    sys.exit(run_xlib_visual_dock())


if __name__ == "__main__":
    main()
